#!/usr/bin/env python3
"""summary.py 的 unittest 测试。

运行方式（在本文件所在目录下）：
    python3 -m unittest -v test_summary.py
"""

from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import summary  # noqa: E402

SCRIPT = Path(__file__).resolve().parent / "summary.py"


def reader_for(text: str):
    """把 CSV 文本包装成 csv.DictReader。"""
    return csv.DictReader(io.StringIO(text, newline=""))


class ParseAmountTests(unittest.TestCase):
    """金额解析：各种书写形式。"""

    def test_plain_numbers(self):
        self.assertEqual(summary.parse_amount("12.5"), Decimal("12.5"))
        self.assertEqual(summary.parse_amount("  -3 "), Decimal("-3"))
        self.assertEqual(summary.parse_amount("0"), Decimal("0"))

    def test_currency_symbols_and_parentheses(self):
        self.assertEqual(summary.parse_amount("¥1,234.56"), Decimal("1234.56"))
        self.assertEqual(summary.parse_amount("$99"), Decimal("99"))
        self.assertEqual(summary.parse_amount("(1,234.56)"), Decimal("-1234.56"))
        self.assertEqual(summary.parse_amount("100 元"), Decimal("100"))

    def test_thousand_separator_and_euro_comma(self):
        self.assertEqual(summary.parse_amount("1,234.56"), Decimal("1234.56"))
        self.assertEqual(summary.parse_amount("1,50"), Decimal("1.50"))
        self.assertEqual(summary.parse_amount("12,34"), Decimal("12.34"))

    def test_invalid_amounts_raise_value_error(self):
        for bad in ("", "   ", None, "abc", "12.3.4", "1,23,4"):
            with self.subTest(value=bad):
                with self.assertRaises(ValueError):
                    summary.parse_amount(bad)


class SummarizeTests(unittest.TestCase):
    """核心汇总逻辑。"""

    def test_groups_and_sums_amount_by_category(self):
        reader = reader_for(
            "category,amount\n"
            "food,10.50\n"
            "travel,20\n"
            "food,4.25\n"
            "travel,5\n"
        )
        result = summary.summarize_reader(reader)

        self.assertEqual(result.totals["food"], Decimal("14.75"))
        self.assertEqual(result.totals["travel"], Decimal("25"))
        self.assertEqual(result.rows_read, 4)
        self.assertEqual(result.skipped, [])
        self.assertEqual(result.total_amount, Decimal("39.75"))

    def test_uses_decimal_so_float_precision_is_preserved(self):
        reader = reader_for("category,amount\nA,0.1\nA,0.2\n")
        result = summary.summarize_reader(reader)
        self.assertEqual(result.totals["A"], Decimal("0.3"))
        self.assertEqual(str(result.totals["A"]), "0.3")

    def test_invalid_amount_is_skipped_and_recorded(self):
        reader = reader_for(
            "category,amount\n"
            "A,10\n"
            "B,oops\n"
            "C,2\n"
        )
        result = summary.summarize_reader(reader)

        self.assertEqual(result.totals, {"A": Decimal("10"), "C": Decimal("2")})
        self.assertEqual(len(result.skipped), 1)
        self.assertEqual(result.skipped[0].line, 3)
        self.assertIn("无法解析", result.skipped[0].reason)

    def test_blank_category_is_skipped(self):
        reader = reader_for("category,amount\n,10\nA,5\n")
        result = summary.summarize_reader(reader)
        self.assertEqual(result.totals, {"A": Decimal("5")})
        self.assertEqual(len(result.skipped), 1)
        self.assertIn("为空", result.skipped[0].reason)

    def test_missing_required_column_raises(self):
        reader = reader_for("category,value\nA,10\n")
        with self.assertRaises(summary.SummaryError) as ctx:
            summary.summarize_reader(reader)
        self.assertIn("amount", str(ctx.exception))

    def test_strict_mode_raises_on_invalid_row(self):
        reader = reader_for("category,amount\nA,10\nB,oops\n")
        with self.assertRaises(summary.SummaryError):
            summary.summarize_reader(reader, strict=True)

    def test_empty_file_without_header_raises(self):
        with self.assertRaises(summary.SummaryError):
            summary.summarize_reader(reader_for(""))

    def test_header_only_file_yields_empty_totals(self):
        result = summary.summarize_reader(reader_for("category,amount\n"))
        self.assertEqual(result.totals, {})
        self.assertEqual(result.rows_read, 0)

    def test_quoted_fields_containing_delimiter_and_newline(self):
        reader = reader_for(
            'category,amount\n'
            '"food, fast","3.50"\n'
            '"multi\nline",2.5\n'
        )
        result = summary.summarize_reader(reader)
        self.assertEqual(result.totals["food, fast"], Decimal("3.50"))
        self.assertEqual(result.totals["multi\nline"], Decimal("2.50"))

    def test_bom_and_padded_header_are_tolerated(self):
        reader = reader_for("\ufeffcategory , amount\nA,1\n")
        result = summary.summarize_reader(reader)
        self.assertEqual(result.totals["A"], Decimal("1"))

    def test_summarize_rows_matches_summarize_reader(self):
        rows = [{"category": "A", "amount": "1.5"}, {"category": "A", "amount": "2.5"}]
        result = summary.summarize_rows(rows, fieldnames=["category", "amount"])
        self.assertEqual(result.totals["A"], Decimal("4.0"))


class FormatTests(unittest.TestCase):
    """输出格式化与排序。"""

    def setUp(self):
        self.summary = summary.Summary(
            totals={"food": Decimal("14.755"), "travel": Decimal("25")},
        )

    def test_default_sort_is_total_desc(self):
        rows = summary.format_totals(self.summary)
        self.assertEqual(rows, [("travel", "25.00"), ("food", "14.76")])

    def test_sort_by_key(self):
        rows = summary.format_totals(self.summary, sort="key")
        self.assertEqual([name for name, _ in rows], ["food", "travel"])

    def test_precision_controls_decimal_places(self):
        rows = summary.format_totals(self.summary, precision=0, sort="key")
        self.assertEqual(rows, [("food", "15"), ("travel", "25")])


class CommandLineTests(unittest.TestCase):
    """命令行端到端测试。"""

    def run_cli(self, *args, stdin=None):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            input=stdin,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )

    def write_csv(self, text, name="data.csv", encoding="utf-8"):
        tmpdir = tempfile.mkdtemp()
        path = os.path.join(tmpdir, name)
        with open(path, "w", encoding=encoding, newline="") as handle:
            handle.write(text)
        return path

    def test_cli_summarizes_file_to_stdout(self):
        path = self.write_csv("category,amount\nfood,10\nfood,2.5\ntravel,30\n")
        proc = self.run_cli(path)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(
            proc.stdout.splitlines(),
            ["category,total", "travel,30.00", "food,12.50"],
        )

    def test_cli_reads_stdin_when_input_is_omitted(self):
        proc = self.run_cli(stdin="category,amount\nA,1.25\n")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout.splitlines(), ["category,total", "A,1.25"])

    def test_cli_json_output(self):
        path = self.write_csv("category,amount\nA,1\nB,2\n")
        proc = self.run_cli(path, "--json")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual(payload["totals"], {"A": "1.00", "B": "2.00"})
        self.assertEqual(payload["rows_read"], 2)
        self.assertEqual(payload["skipped"], [])

    def test_cli_custom_columns_and_output_file(self):
        path = self.write_csv("部门,金额\n研发,100\n研发,50\n销售,20\n")
        out = os.path.join(tempfile.mkdtemp(), "report.csv")
        proc = self.run_cli(path, "--key-column", "部门", "--value-column", "金额", "-o", out)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        with open(out, encoding="utf-8") as handle:
            content = handle.read()
        self.assertIn("研发,150.00", content)
        self.assertIn("销售,20.00", content)

    def test_cli_reports_skipped_rows_on_stderr(self):
        path = self.write_csv("category,amount\nA,10\nB,oops\n")
        proc = self.run_cli(path)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("A,10.00", proc.stdout)
        self.assertNotIn("B,", proc.stdout)
        self.assertIn("跳过", proc.stderr)

    def test_cli_missing_file_returns_error_code(self):
        proc = self.run_cli("/definitely/not/exists.csv")
        self.assertEqual(proc.returncode, 1)
        self.assertIn("找不到输入文件", proc.stderr)

    def test_cli_missing_column_returns_error_code(self):
        path = self.write_csv("category,value\nA,1\n")
        proc = self.run_cli(path)
        self.assertEqual(proc.returncode, 1)
        self.assertIn("缺少必需的列", proc.stderr)

    def test_cli_strict_mode_returns_error_code(self):
        path = self.write_csv("category,amount\nA,1\nB,oops\n")
        proc = self.run_cli(path, "--strict")
        self.assertEqual(proc.returncode, 1)
        self.assertIn("非法", proc.stderr)


class JsonOutputTests(unittest.TestCase):
    """--json 选项的专项测试。"""

    def run_cli(self, *args, stdin=None):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            input=stdin,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )

    def write_csv(self, text, name="data.csv", encoding="utf-8"):
        tmpdir = tempfile.mkdtemp()
        path = os.path.join(tmpdir, name)
        with open(path, "w", encoding=encoding, newline="") as handle:
            handle.write(text)
        return path

    def test_json_output_has_expected_structure(self):
        path = self.write_csv("category,amount\nA,1\nB,2.5\n")
        proc = self.run_cli(path, "--json")
        self.assertEqual(proc.returncode, 0, proc.stderr)

        payload = json.loads(proc.stdout)
        self.assertEqual(
            set(payload), {"totals", "rows_read", "total_amount", "skipped"}
        )
        self.assertEqual(payload["totals"], {"A": "1.00", "B": "2.50"})
        self.assertEqual(payload["rows_read"], 2)
        self.assertEqual(payload["total_amount"], "3.50")
        self.assertEqual(payload["skipped"], [])

    def test_json_output_is_pure_json_without_csv_mixing(self):
        path = self.write_csv("category,amount\nA,1\n")
        proc = self.run_cli(path, "--json")
        # stdout 必须能被 JSON 解析器直接读取，不能混入表头或提示信息
        json.loads(proc.stdout)
        self.assertNotIn("category,total", proc.stdout)

    def test_json_output_reports_skipped_rows(self):
        path = self.write_csv("category,amount\nA,10\nB,oops\n")
        proc = self.run_cli(path, "--json")
        self.assertEqual(proc.returncode, 0, proc.stderr)

        payload = json.loads(proc.stdout)
        self.assertEqual(payload["totals"], {"A": "10.00"})
        self.assertEqual(len(payload["skipped"]), 1)
        self.assertEqual(payload["skipped"][0]["line"], 3)
        self.assertEqual(payload["skipped"][0]["raw"], "oops")
        self.assertIn("无法解析", payload["skipped"][0]["reason"])

    def test_json_output_respects_precision_for_totals_and_total(self):
        path = self.write_csv("category,amount\nA,1\nB,2.5\n")
        proc = self.run_cli(path, "--json", "--precision", "3")
        self.assertEqual(proc.returncode, 0, proc.stderr)

        payload = json.loads(proc.stdout)
        self.assertEqual(payload["totals"], {"A": "1.000", "B": "2.500"})
        # total_amount 必须与 totals 使用同一精度
        self.assertEqual(payload["total_amount"], "3.500")

    def test_json_output_respects_sort(self):
        path = self.write_csv("category,amount\nA,1\nB,9\nC,5\n")
        proc = self.run_cli(path, "--json", "--sort", "key")
        payload = json.loads(proc.stdout)
        self.assertEqual(list(payload["totals"]), ["A", "B", "C"])

        proc = self.run_cli(path, "--json", "--sort", "total-desc")
        payload = json.loads(proc.stdout)
        self.assertEqual(list(payload["totals"]), ["B", "C", "A"])

    def test_json_output_written_to_file_via_output_option(self):
        path = self.write_csv("category,amount\nA,1\n")
        out = os.path.join(tempfile.mkdtemp(), "report.json")
        proc = self.run_cli(path, "--json", "-o", out)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, "")

        with open(out, encoding="utf-8") as handle:
            payload = json.load(handle)
        self.assertEqual(payload["totals"], {"A": "1.00"})

    def test_json_output_supports_custom_column_names(self):
        path = self.write_csv("部门,金额\n研发,100\n研发,50\n")
        proc = self.run_cli(path, "--json", "--key-column", "部门", "--value-column", "金额")
        self.assertEqual(proc.returncode, 0, proc.stderr)

        payload = json.loads(proc.stdout)
        self.assertEqual(payload["totals"], {"研发": "150.00"})
        self.assertEqual(payload["total_amount"], "150.00")

    def test_json_output_keeps_non_ascii_unescaped(self):
        path = self.write_csv("category,amount\n食品,12.50\n")
        proc = self.run_cli(path, "--json")
        self.assertIn("食品", proc.stdout)
        self.assertNotIn("\\u98df", proc.stdout)
        self.assertEqual(json.loads(proc.stdout)["totals"], {"食品": "12.50"})

    def test_json_output_for_empty_result(self):
        path = self.write_csv("category,amount\n")
        proc = self.run_cli(path, "--json")
        self.assertEqual(proc.returncode, 0, proc.stderr)

        payload = json.loads(proc.stdout)
        self.assertEqual(payload["totals"], {})
        self.assertEqual(payload["rows_read"], 0)
        self.assertEqual(payload["total_amount"], "0.00")

    def test_default_output_remains_csv_when_json_not_requested(self):
        path = self.write_csv("category,amount\nA,1\nB,2\n")
        proc = self.run_cli(path)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout.splitlines(), ["category,total", "B,2.00", "A,1.00"])
        with self.assertRaises(json.JSONDecodeError):
            json.loads(proc.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
