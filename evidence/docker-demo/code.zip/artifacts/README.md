# CSV 分类汇总工具（summary.py）

按 `category` 列分组，对 `amount` 列求和的命令行工具与 Python 模块。
**只使用 Python 标准库**（`csv` / `decimal` / `argparse` / `json`），无需 `pip install` 任何第三方依赖。

## 交付物

| 文件 | 说明 |
| --- | --- |
| `summary.py` | 主程序：既可命令行运行，也可作为模块导入 |
| `test_summary.py` | unittest 测试（36 条用例，其中 10 条专门针对 `--json`） |
| `sample.csv` | 示例输入数据，含一行故意写坏的金额用于演示容错 |
| `README.md` | 本使用说明 |

## 环境要求

* Python 3.8 及以上（开发与验证环境为 Python 3.11）
* 无第三方依赖

## 快速开始

```bash
cd artifacts

# 1) 直接汇总，结果打印到标准输出
python3 summary.py sample.csv

# 2) 写入文件
python3 summary.py sample.csv -o report.csv

# 3) 从管道/标准输入读取
cat sample.csv | python3 summary.py

# 4) 输出 JSON，便于后续程序消费（默认 CSV 输出不受影响）
python3 summary.py sample.csv --json
python3 summary.py sample.csv --json | python3 -c "import json,sys; print(json.load(sys.stdin)['total_amount'])"
```

`sample.csv` 的实际输出（默认按金额从大到小排序）：

```
category,total
housing,3000.00
food,210.49
entertainment,60.00
transport,57.75
misc,25.50
```

同时标准错误会提示被跳过的坏行（不影响退出码）：

```
警告: 第 9 行已跳过（无法解析为数字: 'abc'）
```

## 输入格式

标准 CSV，**必须包含表头行**，且表头中要有分组列与数值列：

```csv
category,amount
food,120.50
food,89.99
transport,45.00
```

* 默认分组列为 `category`，数值列为 `amount`，可用 `--key-column` / `--value-column` 改写。
* 表头列名前后的空格以及 UTF-8 BOM 会被自动忽略。
* 字段内含逗号或换行时，按标准 CSV 规则用双引号包裹即可。
* 支持 `utf-8-sig`（默认，已含 BOM）、`utf-8`、`gbk` 等编码，用 `--encoding` 指定。

## 命令行参数

```
python3 summary.py [输入文件] [-o 输出文件] [选项]
```

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `input` | 标准输入 | 输入 CSV 路径；省略或填 `-` 表示从 stdin 读取 |
| `-o, --output` | 标准输出 | 输出文件路径 |
| `--key-column` | `category` | 分组列名 |
| `--value-column` | `amount` | 求和列名 |
| `--delimiter` | `,` | CSV 分隔符（可用 `\t` 表示制表符） |
| `--encoding` | `utf-8-sig` | 输入编码 |
| `--sort` | `total-desc` | 排序：`key` / `key-desc` / `total` / `total-desc` |
| `--precision` | `2` | 金额小数位数（四舍五入，ROUND_HALF_UP） |
| `--json` | 关闭 | 以 JSON 输出 |
| `--no-header` | 关闭 | CSV 输出时不写表头，便于管道拼接 |
| `--strict` | 关闭 | 遇到非法行直接报错退出，而不是跳过 |
| `--quiet` | 关闭 | 不在标准错误输出跳过行的提示 |

示例：

```bash
# 按部门汇总金额并排序
python3 summary.py expenses.csv --key-column 部门 --value-column 金额 --sort key -o 部门汇总.csv

# 制表符分隔、保留 3 位小数
python3 summary.py data.tsv --delimiter $'\t' --precision 3

# 严格模式：任何脏数据都直接失败（退出码 1），便于接入 CI
python3 summary.py data.csv --strict
```

## 输出格式

默认输出为 **CSV**，加 `--json` 后切换为 **JSON**；两种格式互不影响，可同时使用（CSV 走 stdout、JSON 走 `-o` 文件）。

### CSV（默认，原有输出保持不变）

表头为 `<分组列名>,total`，每行一个分组及其合计金额：

```csv
category,total
housing,3000.00
food,210.49
```

### JSON（`--json`）

```json
{
  "totals": { "housing": "3000.00", "food": "210.49" },
  "rows_read": 9,
  "total_amount": "3353.74",
  "skipped": [ { "line": 9, "reason": "无法解析为数字: 'abc'", "raw": "abc" } ]
}
```

字段说明：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `totals` | `object` | 分组名 → 合计金额（字符串，保留 `--precision` 指定的小数位，顺序遵循 `--sort`） |
| `rows_read` | `int` | 读取到的数据行数（不含表头） |
| `total_amount` | `string` | 全部分组金额之和，与 `totals` 使用相同精度 |
| `skipped` | `array` | 被跳过的行，每项含 `line`（行号）、`reason`（原因）、`raw`（原始金额值） |

说明：

* 中文等非 ASCII 字符以原样输出（不转义为 `\uXXXX`），可直接阅读与 `json.loads` 解析。
* 坏行提示仍打印到标准错误，标准输出是**纯净的 JSON**，可直接 `json.loads(proc.stdout)`。
* 没有数据行时 `totals` 为 `{}`、`rows_read` 为 `0`、`total_amount` 为 `"0.00"`。
* `--json` 与 `--precision`、`--sort`、`--key-column`、`--value-column`、`-o` 均可组合使用。

## 金额解析规则

金额使用 `decimal.Decimal` 计算，**不存在浮点误差**（`0.1 + 0.2` 精确等于 `0.3`）。
以下写法均可识别：

| 写法 | 解析结果 |
| --- | --- |
| `123.45` / `-7` | `123.45` / `-7` |
| `1,234.56` | `1234.56`（千分位） |
| `¥1,234.56` / `$99` / `100 元` | `1234.56` / `99` / `100` |
| `(1,234.56)` | `-1234.56`（会计式括号负数） |
| `1,50` | `1.50`（逗号后非 3 位时按小数点处理） |

无法解析的值（如 `abc`、空单元格）、以及分组列为空的行会被**跳过**并记录行号与原因；
加 `--strict` 则立即以退出码 1 失败。

## 退出码

| 退出码 | 含义 |
| --- | --- |
| `0` | 成功（可能包含被跳过的坏行，坏行信息输出到标准错误） |
| `1` | 输入文件不存在、缺少必需列、CSV 解析失败，或 `--strict` 下存在非法行 |
| `2` | 命令行参数错误（argparse 默认行为） |

## 作为 Python 模块使用

```python
import csv
from decimal import Decimal

import summary

# 方式一：直接传入字典行
result = summary.summarize_rows(
    [{"category": "food", "amount": "10.50"},
     {"category": "food", "amount": "4.25"}],
    fieldnames=["category", "amount"],
)
print(result.totals["food"])          # Decimal('14.75')
print(result.total_amount)            # Decimal('14.75')
print(result.skipped)                 # []

# 方式二：配合 csv.DictReader 处理大文件
with open("data.csv", encoding="utf-8-sig", newline="") as fh:
    result = summary.summarize_reader(csv.DictReader(fh))

# 方式三：单条金额解析
summary.parse_amount("¥1,234.56")     # Decimal('1234.56')

# 格式化输出
for name, total in summary.format_totals(result, precision=2, sort="total-desc"):
    print(name, total)
```

常用返回对象：

* `Summary.totals`：`dict[str, Decimal]`，分组 → 合计金额
* `Summary.total_amount`：全部金额之和
* `Summary.rows_read`：读取到的数据行数
* `Summary.skipped`：被跳过的行列表（`line` / `reason` / `raw`）
* `SummaryError`：致命错误（文件缺失、缺少必需列等）

## 运行测试

```bash
cd artifacts
python3 -m unittest -v test_summary.py
```

或使用标准库发现模式：

```bash
cd artifacts
python3 -m unittest discover -v -p "test_*.py"
```

测试覆盖：分组求和、Decimal 精度、坏行跳过与记录、缺列报错、`--strict` 模式、
带逗号/换行的引号字段、BOM 与表头空格、表头只有一列、排序与精度、
以及 CLI 端到端（文件输入、stdin、输出文件、错误退出码）。

其中 `--json` 专项测试 10 条：输出结构与字段类型、标准输出为纯净 JSON（不与 CSV 混排）、
坏行写入 `skipped`、`totals` 与 `total_amount` 精度一致、`--sort` 生效、
配合 `-o` 写入 JSON 文件、自定义列名、非 ASCII 不转义、空结果输出，
以及**未加 `--json` 时默认 CSV 输出保持不变**的回归测试。

最近一次执行结果：**Ran 36 tests — OK**（全部通过）。

## 设计取舍

* 坏行默认**跳过而非终止**，保证单条脏数据不会让整批报表失败；需要严格时用 `--strict`。
* 金额一律走 `Decimal`，输出按 `--precision` 统一四舍五入，保证同一分组多次运行输出一致。
* 排序在分组名上做了次级排序，因此金额相同的分组顺序稳定可复现。
* 采用流式逐行读取，`DictReader` 不会把整个文件读入内存，可处理较大的 CSV。
