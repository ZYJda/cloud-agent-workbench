#!/usr/bin/env python3
"""按 category 列汇总 CSV 中的 amount 列。

仅依赖 Python 标准库（csv / decimal / argparse 等），可直接用 `python3 summary.py` 运行。

核心能力：
  * 以 category 为分组键，对 amount 求和；
  * 使用 Decimal 精确计算，避免浮点误差（0.1 + 0.2 == 0.3）；
  * 宽容解析金额：支持千分位、货币符号、括号负数、欧式逗号小数；
  * 坏行跳过并记录（可用 --strict 改为直接报错）；
  * 输出 CSV（默认）或 JSON，可排序、可指定小数精度。

示例：
    python3 summary.py data.csv
    python3 summary.py data.csv --sort total-desc --precision 2 -o report.csv
    cat data.csv | python3 summary.py --json
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Iterable, Mapping, Sequence, TextIO

__all__ = [
    "SummaryError",
    "SkippedRow",
    "Summary",
    "parse_amount",
    "summarize_reader",
    "summarize_rows",
    "format_totals",
    "build_parser",
    "main",
]

DEFAULT_KEY_COLUMN = "category"
DEFAULT_VALUE_COLUMN = "amount"
DEFAULT_ENCODING = "utf-8-sig"
DEFAULT_PRECISION = 2
SORT_CHOICES = ("key", "key-desc", "total", "total-desc")
TOTAL_COLUMN_NAME = "total"

# 允许出现在金额前后的货币符号。
CURRENCY_SYMBOLS = ("¥", "$", "€", "£", "₩", "₽", "元", "RMB", "CNY", "USD", "EUR")

# 1,234.56 / 1,234,567.89
_THOUSANDS_PATTERN = re.compile(r"^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$")
# 1234,56（欧式写法：逗号作小数点）
_EURO_PATTERN = re.compile(r"^[+-]?\d+,\d+$")


class SummaryError(Exception):
    """汇总过程中的致命错误（文件不存在、缺少必需的列等）。"""


@dataclass(frozen=True)
class SkippedRow:
    """被跳过的一行数据及其原因。"""

    line: int
    reason: str
    raw: str

    def as_dict(self) -> dict:
        return {"line": self.line, "reason": self.reason, "raw": self.raw}


@dataclass
class Summary:
    """汇总结果。"""

    totals: dict[str, Decimal] = field(default_factory=dict)
    skipped: list[SkippedRow] = field(default_factory=list)
    rows_read: int = 0

    @property
    def total_amount(self) -> Decimal:
        return sum(self.totals.values(), Decimal("0"))


def parse_amount(raw: object) -> Decimal:
    """把金额文本解析为 Decimal。

    支持：空白、千分位逗号、货币符号、括号负数（会计写法）、欧式逗号小数。
    解析失败时抛出 ValueError，调用方负责转为跳过或报错。
    """
    if raw is None:
        raise ValueError("金额为空")

    text = str(raw).strip().replace("\u00a0", "").replace("\u3000", "")
    if not text:
        raise ValueError("金额为空")

    negative = False
    if text.startswith("(") and text.endswith(")"):
        negative = True
        text = text[1:-1].strip()

    for symbol in CURRENCY_SYMBOLS:
        if text.upper().startswith(symbol.upper()):
            text = text[len(symbol):].strip()
            break
        if text.upper().endswith(symbol):
            text = text[: -len(symbol)].strip()
            break

    text = text.replace(" ", "")
    if not text:
        raise ValueError("金额为空")

    if "," in text:
        text = _normalize_comma(text)

    try:
        value = Decimal(text)
    except InvalidOperation:
        raise ValueError(f"无法解析为数字: {raw!r}") from None

    if not value.is_finite():
        raise ValueError(f"不是有限数字: {raw!r}")

    return -value if negative else value


def _normalize_comma(text: str) -> str:
    """处理金额中的逗号：优先按千分位分隔符，必要时按欧式小数点。"""
    if _THOUSANDS_PATTERN.match(text):
        return text.replace(",", "")
    if _EURO_PATTERN.match(text):
        head, tail = text.split(",")
        # 逗号后恰好三位数字时按千分位理解（1,500 -> 1500），否则视为小数点（1,50 -> 1.50）
        if len(tail) == 3:
            return text.replace(",", "")
        return f"{head}.{tail}"
    raise ValueError(f"逗号位置不合法: {text!r}")


def _resolve_columns(
    fieldnames: Sequence[str] | None,
    key_column: str,
    value_column: str,
) -> tuple[str, str]:
    """校验表头并返回实际使用的列名（容忍表头前后的空格）。"""
    if not fieldnames:
        raise SummaryError("CSV 文件为空或缺少表头")
    actual: dict[str, str] = {}
    for name in fieldnames:
        if name is None:
            continue
        actual.setdefault(name.replace("\ufeff", "").strip(), name)
    missing = [
        name
        for name in (key_column, value_column)
        if name.replace("\ufeff", "").strip() not in actual
    ]
    if missing:
        raise SummaryError(
            "CSV 中缺少必需的列: " + ", ".join(missing) + "；实际表头为: " + ", ".join(fieldnames)
        )
    return (
        actual[key_column.replace("\ufeff", "").strip()],
        actual[value_column.replace("\ufeff", "").strip()],
    )


def summarize_reader(
    reader,
    key_column: str = DEFAULT_KEY_COLUMN,
    value_column: str = DEFAULT_VALUE_COLUMN,
    *,
    strict: bool = False,
) -> Summary:
    """汇总 csv.DictReader 读取的行，返回 Summary。"""
    key_field, value_field = _resolve_columns(
        getattr(reader, "fieldnames", None), key_column, value_column
    )

    summary = Summary()
    for row in reader:
        line = getattr(reader, "line_num", summary.rows_read + 2)
        summary.rows_read += 1
        category = (row.get(key_field) or "").strip()
        raw_amount = row.get(value_field)

        try:
            amount = parse_amount(raw_amount)
        except ValueError as exc:
            reason = str(exc)
            if strict:
                raise SummaryError(f"第 {line} 行数据非法: {reason}") from None
            summary.skipped.append(SkippedRow(line=line, reason=reason, raw=str(raw_amount)))
            continue

        if not category:
            reason = f"分组列 {key_column!r} 为空"
            if strict:
                raise SummaryError(f"第 {line} 行数据非法: {reason}")
            summary.skipped.append(SkippedRow(line=line, reason=reason, raw=str(raw_amount)))
            continue

        summary.totals[category] = summary.totals.get(category, Decimal("0")) + amount

    return summary


def summarize_rows(
    rows: Iterable[Mapping[str, object]],
    key_column: str = DEFAULT_KEY_COLUMN,
    value_column: str = DEFAULT_VALUE_COLUMN,
    *,
    fieldnames: Sequence[str] | None = None,
    strict: bool = False,
    start_line: int = 2,
) -> Summary:
    """汇总字典序列形式的行（表头行之后的数据行）。"""
    key_field = value_field = None
    if fieldnames is not None:
        key_field, value_field = _resolve_columns(fieldnames, key_column, value_column)

    summary = Summary()
    for offset, row in enumerate(rows):
        line = start_line + offset
        summary.rows_read += 1
        category = str(row.get(key_field if key_field is not None else key_column) or "").strip()
        raw_amount = row.get(value_field if value_field is not None else value_column)

        try:
            amount = parse_amount(raw_amount)
        except ValueError as exc:
            reason = str(exc)
            if strict:
                raise SummaryError(f"第 {line} 行数据非法: {reason}") from None
            summary.skipped.append(SkippedRow(line=line, reason=reason, raw=str(raw_amount)))
            continue

        if not category:
            reason = f"分组列 {key_column!r} 为空"
            if strict:
                raise SummaryError(f"第 {line} 行数据非法: {reason}")
            summary.skipped.append(SkippedRow(line=line, reason=reason, raw=str(raw_amount)))
            continue

        summary.totals[category] = summary.totals.get(category, Decimal("0")) + amount

    return summary


def _quantize(value: Decimal, precision: int) -> Decimal:
    exponent = Decimal(1).scaleb(-precision)
    return value.quantize(exponent, rounding=ROUND_HALF_UP)


def format_totals(
    summary: Summary,
    precision: int = DEFAULT_PRECISION,
    sort: str = "total-desc",
) -> list[tuple[str, str]]:
    """把汇总结果格式化为 (分组, 金额字符串) 列表，并按指定规则排序。"""
    items = [(name, _quantize(value, precision)) for name, value in summary.totals.items()]

    if sort == "key":
        items.sort(key=lambda item: item[0])
    elif sort == "key-desc":
        items.sort(key=lambda item: item[0], reverse=True)
    elif sort == "total":
        items.sort(key=lambda item: (item[1], item[0]))
    elif sort == "total-desc":
        items.sort(key=lambda item: (-item[1], item[0]))
    else:  # pragma: no cover - argparse 已限制取值
        raise SummaryError(f"未知的排序方式: {sort}")

    return [(name, format(value, "f")) for name, value in items]


def _write_csv(
    stream: TextIO,
    rows: Sequence[tuple[str, str]],
    key_column: str,
    *,
    header: bool = True,
    delimiter: str = ",",
) -> None:
    writer = csv.writer(stream, delimiter=delimiter, lineterminator="\n")
    if header:
        writer.writerow([key_column, TOTAL_COLUMN_NAME])
    for name, value in rows:
        writer.writerow([name, value])


def _write_json(
    stream: TextIO,
    summary: Summary,
    rows: Sequence[tuple[str, str]],
    precision: int = DEFAULT_PRECISION,
) -> None:
    payload = {
        "totals": {name: value for name, value in rows},
        "rows_read": summary.rows_read,
        "total_amount": format(_quantize(summary.total_amount, precision), "f"),
        "skipped": [item.as_dict() for item in summary.skipped],
    }
    json.dump(payload, stream, ensure_ascii=False, indent=2)
    stream.write("\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="summary.py",
        description="按 category 列汇总 CSV 中的 amount 列（仅依赖标准库）。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python3 summary.py data.csv\n"
            "  python3 summary.py data.csv --sort total-desc --precision 2 -o report.csv\n"
            "  python3 summary.py data.csv --key-column 部门 --value-column 金额\n"
            "  cat data.csv | python3 summary.py --json\n"
        ),
    )
    parser.add_argument(
        "input",
        nargs="?",
        help="输入 CSV 路径；省略或使用 - 时从标准输入读取",
    )
    parser.add_argument("-o", "--output", help="输出文件路径；默认写入标准输出")
    parser.add_argument(
        "--key-column",
        default=DEFAULT_KEY_COLUMN,
        help=f"分组列名，默认 {DEFAULT_KEY_COLUMN}",
    )
    parser.add_argument(
        "--value-column",
        default=DEFAULT_VALUE_COLUMN,
        help=f"求和列名，默认 {DEFAULT_VALUE_COLUMN}",
    )
    parser.add_argument("--delimiter", default=",", help="CSV 分隔符，默认逗号 ,")
    parser.add_argument(
        "--encoding",
        default=DEFAULT_ENCODING,
        help=f"输入编码，默认 {DEFAULT_ENCODING}（自动去除 UTF-8 BOM）",
    )
    parser.add_argument(
        "--sort",
        choices=SORT_CHOICES,
        default="total-desc",
        help="输出排序方式，默认 total-desc（按金额从大到小）",
    )
    parser.add_argument(
        "--precision",
        type=int,
        default=DEFAULT_PRECISION,
        help=f"金额小数位数，默认 {DEFAULT_PRECISION}",
    )
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出结果")
    parser.add_argument("--no-header", action="store_true", help="CSV 输出时不写表头")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="遇到非法行直接报错退出，而不是跳过",
    )
    parser.add_argument("--quiet", action="store_true", help="不在标准错误输出跳过行的提示")
    return parser


def _open_input(path: str | None, encoding: str):
    """返回 (文件对象, 是否需要关闭)。"""
    if path is None or path == "-":
        return sys.stdin, False
    try:
        handle = open(path, "r", encoding=encoding, newline="")
    except FileNotFoundError:
        raise SummaryError(f"找不到输入文件: {path}") from None
    except OSError as exc:
        raise SummaryError(f"无法读取输入文件 {path}: {exc}") from None
    return handle, True


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.precision < 0:
        parser.error("--precision 不能为负数")

    try:
        handle, should_close = _open_input(args.input, args.encoding)
    except SummaryError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 1

    try:
        reader = csv.DictReader(handle, delimiter=args.delimiter)
        summary = summarize_reader(
            reader,
            key_column=args.key_column,
            value_column=args.value_column,
            strict=args.strict,
        )
    except SummaryError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 1
    except csv.Error as exc:
        print(f"错误: CSV 解析失败: {exc}", file=sys.stderr)
        return 1
    finally:
        if should_close:
            handle.close()

    rows = format_totals(summary, precision=args.precision, sort=args.sort)

    if args.output:
        try:
            out_handle = open(args.output, "w", encoding="utf-8", newline="")
        except OSError as exc:
            print(f"错误: 无法写入输出文件 {args.output}: {exc}", file=sys.stderr)
            return 1
        with out_handle:
            if args.json:
                _write_json(out_handle, summary, rows, precision=args.precision)
            else:
                _write_csv(out_handle, rows, args.key_column, header=not args.no_header)
    else:
        if args.json:
            _write_json(sys.stdout, summary, rows, precision=args.precision)
        else:
            _write_csv(sys.stdout, rows, args.key_column, header=not args.no_header)

    if summary.skipped and not args.quiet:
        for item in summary.skipped:
            print(f"警告: 第 {item.line} 行已跳过（{item.reason}）", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
