#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""销售数据核对脚本：读取 uploads/579c3a4c-sales.csv，用 Decimal 精确计算
   两个月收入/成本/毛利/毛利率、环比、分地区分产品明细，并做数据质量校验。
   图表中的每一个数字都由本脚本输出，未做人工录入。
"""
import csv
from collections import OrderedDict
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 28

ROOT = Path(__file__).resolve().parent.parent
CSV = ROOT / "uploads" / "579c3a4c-sales.csv"

D0 = Decimal("0")


def dec(x):
    return Decimal(str(x).strip())


def money(x):
    """千分位金额，无小数（数据本身为整数元）。"""
    return f"{x:,.0f}"


def pct(x, digits=2):
    """x 为 Decimal 的比例（如 0.1142857），转百分比字符串。"""
    q = Decimal(10) ** (-digits)
    return str((x * 100).quantize(q))


def signed(x):
    return f"+{money(x)}" if x > 0 else money(x)


def signed_pct(x, digits=2):
    q = Decimal(10) ** (-digits)
    v = (x * 100).quantize(q)
    return ("+" if v > 0 else "") + str(v)


# ---------------------------------------------------------------- 读取 + 校验
rows = []
with CSV.open(encoding="utf-8-sig", newline="") as fh:
    reader = csv.DictReader(fh)
    header = reader.fieldnames
    for i, r in enumerate(reader, start=2):  # 行号含表头
        rec = {
            "line": i,
            "month": (r["month"] or "").strip(),
            "region": (r["region"] or "").strip(),
            "product": (r["product"] or "").strip(),
            "revenue": dec(r["revenue"]),
            "cost": dec(r["cost"]),
        }
        rows.append(rec)

checks = []


def check(name, ok, detail=""):
    checks.append((name, ok, detail))
    return ok


check("表头字段完整", header == ["month", "region", "product", "revenue", "cost"], str(header))
check("无空值/空白字符", all(all(str(v).strip() != "" for v in r.values()) for r in rows))
check("行数=6", len(rows) == 6, f"实际 {len(rows)}")

months = sorted({r["month"] for r in rows})
check("仅两个月且为 2026-09 / 2026-10", months == ["2026-09", "2026-10"], str(months))

regions = sorted({r["region"] for r in rows})
products = sorted({r["product"] for r in rows})
check("地区集合", regions == ["华东", "华南"], str(regions))
check("产品集合", products == ["专业版", "基础版"], str(products))

keys = [(r["month"], r["region"], r["product"]) for r in rows]
check("组合无重复", len(keys) == len(set(keys)))
check("金额均为非负整数", all(r["revenue"] >= 0 and r["cost"] >= 0 for r in rows))
check("每行 毛利>0", all(r["revenue"] - r["cost"] > 0 for r in rows))

# 组合覆盖：month x (region, product)
combos_seen = {(r["month"], r["region"], r["product"]) for r in rows}
all_combos = {(m, r_, p) for m in months for r_ in regions for p in products}
missing = sorted(all_combos - combos_seen)
check("存在缺失组合(华南无基础版)", missing == [("2026-09", "华南", "基础版"),
                                              ("2026-10", "华南", "基础版")], str(missing))


# ---------------------------------------------------------------- 聚合
def agg(subset):
    rev = sum((r["revenue"] for r in subset), D0)
    cost = sum((r["cost"] for r in subset), D0)
    gp = rev - cost
    gm = (gp / rev) if rev else None
    return {"rev": rev, "cost": cost, "gp": gp, "gm": gm, "n": len(subset)}


by_month = OrderedDict()
for m in months:
    by_month[m] = agg([r for r in rows if r["month"] == m])

M0, M1 = months[0], months[1]
A, B = by_month[M0], by_month[M1]

# ---------------------------------------------------------------- 输出
print("=" * 78)
print(f"数据源: {CSV.relative_to(ROOT)}   行数: {len(rows)}   月份: {M0} -> {M1}")
print("=" * 78)

print("\n【数据质量校验】")
for name, ok, detail in checks:
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
print(f"  校验结果: {sum(1 for _, ok, _ in checks if ok)}/{len(checks)} 通过")

print("\n【合计口径】")
print(f"{'项目':<10}{M0:>14}{M1:>14}{'环比':>14}{'环比%':>12}")
for k, lbl in [("rev", "收入"), ("cost", "成本"), ("gp", "毛利")]:
    a, b = A[k], B[k]
    print(f"{lbl:<10}{money(a):>14}{money(b):>14}{signed(b - a):>14}{signed_pct((b - a) / a) + '%':>12}")
gm_delta = (B["gm"] - A["gm"]) * 100
print(f"{'毛利率':<10}{pct(A['gm']) + '%':>14}{pct(B['gm']) + '%':>14}"
      f"{('+' if gm_delta > 0 else '') + str(gm_delta.quantize(Decimal('0.01'))) + 'pp':>14}{'':>12}")

print("\n【分地区 x 分产品 明细】")
print(f"{'月份':<9}{'地区':<7}{'产品':<8}{'收入':>10}{'成本':>10}{'毛利':>10}{'毛利率':>9}"
      f"{'收入环比':>12}{'成本环比':>12}{'毛利环比':>12}{'毛利率变化':>11}")
seg_rows = []
for (region, product) in [(r, p) for r in regions for p in products]:
    a = agg([r for r in rows if r["month"] == M0 and r["region"] == region and r["product"] == product])
    b = agg([r for r in rows if r["month"] == M1 and r["region"] == region and r["product"] == product])
    if a["n"] == 0 and b["n"] == 0:
        continue
    d_gm = (b["gm"] - a["gm"]) * 100
    seg_rows.append((region, product, a, b, d_gm))
    print(f"{M0:<9}{region:<7}{product:<8}{money(a['rev']):>10}{money(a['cost']):>10}"
          f"{money(a['gp']):>10}{pct(a['gm']) + '%':>9}"
          f"{signed(b['rev'] - a['rev']):>12}{signed(b['cost'] - a['cost']):>12}"
          f"{signed(b['gp'] - a['gp']):>12}"
          f"{('+' if d_gm > 0 else '') + str(d_gm.quantize(Decimal('0.01'))) + 'pp':>11}")
    print(f"{M1:<9}{region:<7}{product:<8}{money(b['rev']):>10}{money(b['cost']):>10}"
          f"{money(b['gp']):>10}{pct(b['gm']) + '%':>9}")
    print(f"{'环比%':<9}{region:<7}{product:<8}"
          f"{signed_pct((b['rev'] - a['rev']) / a['rev']) + '%':>10}"
          f"{signed_pct((b['cost'] - a['cost']) / a['cost']) + '%':>10}"
          f"{signed_pct((b['gp'] - a['gp']) / a['gp']) + '%':>10}")

print("\n【贡献分解：收入环比变动归因】(占净变动 = 该分部变动 / 净变动; 超过100%表示其他分部为负贡献)")
total_delta = B["rev"] - A["rev"]
acc = D0
for region, product, a, b, _ in seg_rows:
    d = b["rev"] - a["rev"]
    acc += d
    share = (d / total_delta) if total_delta else None
    note = " (单独一个分部即可覆盖全部净增)" if share is not None and share > 1 else ""
    print(f"  {region}/{product}: {signed(d):>9}  占净变动 {pct(share) + '%' if share is not None else 'n/a':>10}{note}")
check("分项收入变动之和 == 总变动", acc == total_delta, f"{acc} vs {total_delta}")

print("\n【集中度：剔除华东/专业版后的其余业务】")
rest_a = agg([r for r in rows if r["month"] == M0 and not (r["region"] == "华东" and r["product"] == "专业版")])
rest_b = agg([r for r in rows if r["month"] == M1 and not (r["region"] == "华东" and r["product"] == "专业版")])
for lbl, x, y in [("收入", rest_a["rev"], rest_b["rev"]), ("成本", rest_a["cost"], rest_b["cost"]),
                  ("毛利", rest_a["gp"], rest_b["gp"])]:
    print(f"  {lbl}: {money(x):>9} -> {money(y):>9}   环比 {signed(y - x):>8}  {signed_pct((y - x) / x) + '%':>8}")
d_rest_gm = (rest_b["gm"] - rest_a["gm"]) * 100
print(f"  毛利率: {pct(rest_a['gm'])}% -> {pct(rest_b['gm'])}%  "
      f"({('+' if d_rest_gm > 0 else '') + str(d_rest_gm.quantize(Decimal('0.01')))}pp)")

print("\n【毛利率逐笔变化（成本占收入比）】")
for r in rows:
    ratio = (r["cost"] / r["revenue"] * 100).quantize(Decimal("0.1"))
    print(f"  {r['month']} {r['region']}/{r['product']}: 成本率 {ratio}%  毛利率 {pct((r['revenue'] - r['cost']) / r['revenue'], 0)}%"
          f"  (行 {r['line']})")

print("\n【汇总字典(供报告引用)】")
summary = {
    "months": months,
    "totals": {M0: {k: str(v) for k, v in A.items() if k != "n"},
               M1: {k: str(v) for k, v in B.items() if k != "n"}},
    "d_rev": str(total_delta), "d_rev_pct": signed_pct((B["rev"] - A["rev"]) / A["rev"]),
    "d_cost": str(B["cost"] - A["cost"]), "d_cost_pct": signed_pct((B["cost"] - A["cost"]) / A["cost"]),
    "d_gp": str(B["gp"] - A["gp"]), "d_gp_pct": signed_pct((B["gp"] - A["gp"]) / A["gp"]),
    "gm0": pct(A["gm"]), "gm1": pct(B["gm"]),
    "d_gm_pp": str((gm_delta).quantize(Decimal("0.01"))),
    "rest_rev": [str(rest_a["rev"]), str(rest_b["rev"])],
    "rest_cost": [str(rest_a["cost"]), str(rest_b["cost"])],
    "rest_gp": [str(rest_a["gp"]), str(rest_b["gp"])],
    "rest_gm": [pct(rest_a["gm"]), pct(rest_b["gm"])],
    "rest_d_gp_pct": signed_pct((rest_b["gp"] - rest_a["gp"]) / rest_a["gp"]),
    "checks_passed": sum(1 for _, ok, _ in checks if ok),
    "checks_total": len(checks),
}
for k, v in summary.items():
    print(f"  {k}: {v}")

print("\n" + "=" * 78)
