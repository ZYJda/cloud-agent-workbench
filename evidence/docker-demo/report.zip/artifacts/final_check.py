#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""终检：从 CSV 独立复算所有关键数字，断言它们确实出现在 report.md 中，
   并校验管理层摘要长度 <= 150 字、章节结构完整。"""
import re
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CSVP = ROOT / "uploads" / "579c3a4c-sales.csv"
RPT = ROOT / "artifacts" / "report.md"

rows = []
for line in CSVP.read_text(encoding="utf-8").strip().splitlines()[1:]:
    m, reg, prod, rev, cost = line.split(",")
    rows.append((m, reg, prod, Decimal(rev), Decimal(cost)))

def pick(month, region=None, product=None):
    sel = [r for r in rows if r[0] == month and (region is None or r[1] == region)
           and (product is None or r[2] == product)]
    rev = sum((r[3] for r in sel), Decimal(0))
    cost = sum((r[4] for r in sel), Decimal(0))
    return rev, cost, rev - cost

rpt_raw = RPT.read_text(encoding="utf-8")
# 归一化排版减号 U+2212 -> ASCII "-"，避免因字符形态不同造成误判
rpt = rpt_raw.replace("\u2212", "-")
fails = []

def must(label, token):
    if token not in rpt:
        fails.append(f"{label}: 报告中缺少 '{token}'")

# 合计
for m in ("2026-09", "2026-10"):
    rev, cost, gp = pick(m)
    for v in (rev, cost, gp):
        must(f"{m} 金额", f"{int(v):,}")
    gm = gp / rev * 100
    must(f"{m} 毛利率", f"{gm.quantize(Decimal('0.01'))}%")

a_rev, a_cost, a_gp = pick("2026-09")
b_rev, b_cost, b_gp = pick("2026-10")
must("收入环比额", f"+{int(b_rev - a_rev):,}")
must("成本环比额", f"+{int(b_cost - a_cost):,}")
must("毛利环比额", f"+{int(b_gp - a_gp):,}")
must("收入环比%", f"+{(b_rev / a_rev - 1) * 100:.2f}%")
must("成本环比%", f"+{(b_cost / a_cost - 1) * 100:.2f}%")
must("毛利环比%", f"+{(b_gp / a_gp - 1) * 100:.2f}%")
must("毛利率变动", f"+{((b_gp / b_rev) - (a_gp / a_rev)) * 100:.2f}pp")

# 分部
for region, product in (("华东", "专业版"), ("华东", "基础版"), ("华南", "专业版")):
    ar, ac, ag = pick("2026-09", region, product)
    br, bc, bg = pick("2026-10", region, product)
    must(f"{region}/{product} 收入9月", f"{int(ar):,}")
    must(f"{region}/{product} 收入10月", f"{int(br):,}")
    must(f"{region}/{product} 成本9月", f"{int(ac):,}")
    must(f"{region}/{product} 成本10月", f"{int(bc):,}")
    must(f"{region}/{product} 毛利9月", f"{int(ag):,}")
    must(f"{region}/{product} 毛利10月", f"{int(bg):,}")
    must(f"{region}/{product} 毛利率9月", f"{(ag / ar * 100).quantize(Decimal('0.01'))}%")
    must(f"{region}/{product} 毛利率10月", f"{(bg / br * 100).quantize(Decimal('0.01'))}%")
    sign = "+" if (br - ar) > 0 else "-"
    must(f"{region}/{product} 收入环比额", f"{sign}{int(abs(br - ar)):,}")
    must(f"{region}/{product} 收入环比%", f"{sign}{abs((br / ar - 1) * 100):.2f}%")

# 贡献分解
net = b_rev - a_rev
for region, product in (("华东", "专业版"), ("华东", "基础版"), ("华南", "专业版")):
    ar, _, _ = pick("2026-09", region, product)
    br, _, _ = pick("2026-10", region, product)
    share = (br - ar) / net * 100
    must(f"{region}/{product} 贡献占比", f"{share.quantize(Decimal('0.01'))}%")

# 其余业务（剔除华东/专业版）
def pick_rest(month):
    sel = [r for r in rows if r[0] == month and not (r[1] == "华东" and r[2] == "专业版")]
    rev = sum((r[3] for r in sel), Decimal(0)); cost = sum((r[4] for r in sel), Decimal(0))
    return rev, cost, rev - cost
ra, rc, rg = pick_rest("2026-09")
rb, rc2, rg2 = pick_rest("2026-10")
for v in (ra, rb, rc, rc2, rg, rg2):
    must("其余业务金额", f"{int(v):,}")
must("其余业务收入环比%", f"-{abs((rb / ra - 1) * 100):.2f}%")
must("其余业务毛利环比%", f"-{abs((rg2 / rg - 1) * 100):.2f}%")
must("其余业务毛利率9月", f"{(rg / ra * 100).quantize(Decimal('0.01'))}%")
must("其余业务毛利率10月", f"{(rg2 / rb * 100).quantize(Decimal('0.01'))}%")
must("其余业务毛利率变动", f"-{abs(((rg2 / rb) - (rg / ra)) * 100):.2f}pp")

# 管理层摘要长度
m = re.search(r"## 五、管理层摘要[^\n]*\n\n(.+?)\n", rpt)
if not m:
    fails.append("未找到管理层摘要段落")
else:
    s = m.group(1).strip()
    n = len(s)
    han = sum(1 for c in s if chr(0x4e00) <= c <= chr(0x9fff))
    print("管理层摘要长度: %d 字符 (汉字 %d 个)" % (n, han))
    if n > 150:
        fails.append(f"管理层摘要超过 150 字: {n}")

# 结构检查
for h in ("## 一、核心数字", "## 二、已知事实", "## 三、推测", "## 四、数据局限",
          "## 五、管理层摘要", "## 六、下周行动"):
    if h not in rpt:
        fails.append(f"缺少章节: {h}")
acts = re.search(r"## 六、下周行动（三项）\n(.*)", rpt, re.S)
if not acts:
    fails.append("缺少下周行动章节")
else:
    n_items = len(re.findall(r"^\d+\. \*\*", acts.group(1), re.M))
    print(f"下周行动条数: {n_items}")
    if n_items != 3:
        fails.append(f"下周行动应为 3 项，实为 {n_items}")

print(f"\n断言总数: {len(fails)} 个失败")
if fails:
    for f in fails:
        print("  FAIL:", f)
    raise SystemExit(1)
print("全部通过：报告中每个数字均与 CSV 独立复算一致。")
