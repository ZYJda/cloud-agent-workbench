# -*- coding: utf-8 -*-
"""独立校验：重新计算关键指标，并断言 artifacts/report.md 中出现对应数值。"""
import csv, os, sys
from decimal import Decimal as D, ROUND_HALF_UP

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = list(csv.DictReader(open(os.path.join(BASE, "uploads", "c7d8986b-sales.csv"), encoding="utf-8-sig")))
report = open(os.path.join(BASE, "artifacts", "report.md"), encoding="utf-8-sig").read()

def q(x):
    return str(x.quantize(D("0.01"), rounding=ROUND_HALF_UP))

def p(x):
    return q(x * 100) + "%"

def cmt(x):
    """金额 -> 千分位整数形式（与报告表格写法一致）。"""
    return "{:,}".format(int(x))

m = {}
for r in rows:
    k = r["month"]
    m.setdefault(k, {"rev": D(0), "cost": D(0)})
    m[k]["rev"] += D(r["revenue"]); m[k]["cost"] += D(r["cost"])
m0, m1 = "2026-09", "2026-10"

facts = {
    "9月收入": cmt(m[m0]["rev"]), "9月成本": cmt(m[m0]["cost"]),
    "9月毛利": cmt(m[m0]["rev"] - m[m0]["cost"]),
    "9月毛利率": p((m[m0]["rev"] - m[m0]["cost"]) / m[m0]["rev"]),
    "10月收入": cmt(m[m1]["rev"]), "10月成本": cmt(m[m1]["cost"]),
    "10月毛利": cmt(m[m1]["rev"] - m[m1]["cost"]),
    "10月毛利率": p((m[m1]["rev"] - m[m1]["cost"]) / m[m1]["rev"]),
    "收入环比": p((m[m1]["rev"] - m[m0]["rev"]) / m[m0]["rev"]),
    "成本环比": p((m[m1]["cost"] - m[m0]["cost"]) / m[m0]["cost"]),
    "毛利环比": p(((m[m1]["rev"] - m[m1]["cost"]) - (m[m0]["rev"] - m[m0]["cost"])) / (m[m0]["rev"] - m[m0]["cost"])),
    "毛利率变动pp": q(((m[m1]["rev"] - m[m1]["cost"]) / m[m1]["rev"] - (m[m0]["rev"] - m[m0]["cost"]) / m[m0]["rev"]) * 100),
    "华东9月占比": p(D(36000 + 10000) / m[m0]["rev"]),
    "华东10月占比": p(D(45000 + 12000) / m[m1]["rev"]),
    "华南9月占比": p(D(24000) / m[m0]["rev"]),
    "华南10月占比": p(D(21000) / m[m1]["rev"]),
}

print("=" * 70)
print("A. 重算关键指标")
print("=" * 70)
for k, v in facts.items():
    print(f"  {k:<14} = {v}")

print()
print("=" * 70)
print("B. 断言报告中包含这些数值")
print("=" * 70)
fails = []
for k, v in facts.items():
    ok = v in report
    # 负号/全角差异处理：百分比允许带 +/- 前缀
    if not ok and v.replace("-", "−") in report:
        ok = True
    print(f"  [{'OK ' if ok else 'MISS'}] {k:<14} {v}")
    if not ok:
        fails.append(k)

# 分部与归因数值
seg_expect = [
    ("+9,000 (+25.00%)", "华东专业版收入环比"),
    ("+2,000 (+20.00%)", "华东基础版收入环比"),
    ("−3,000 (−12.50%)", "华南专业版收入环比"),
    ("+6,750 (+37.50%)", "华东专业版毛利环比"),
    ("+600 (+20.00%)", "华东基础版毛利环比"),
    ("−2,250 (−23.44%)", "华南专业版毛利环比"),
    ("+5.00pp", "华东专业版毛利率变动"),
    ("−5.00pp", "华南专业版毛利率变动"),
    ("112.50%", "华东专业版收入贡献占比"),
    ("−37.50%", "华南专业版收入贡献占比"),
    ("132.35%", "华东专业版毛利贡献占比"),
    ("−44.12%", "华南专业版毛利贡献占比"),
    ("+0.86pp", "结构效应"),
    ("+1.20pp", "分部自身毛利率效应"),
    ("50.00% → 55.00%", "华东专业版毛利率"),
    ("40.00% → 35.00%", "华南专业版毛利率"),
    ("30.00% → 30.00%", "华东基础版毛利率"),
]
print()
for needle, label in seg_expect:
    ok = needle in report
    print(f"  [{'OK ' if ok else 'MISS'}] {label:<26} {needle}")
    if not ok:
        fails.append(label)

print()
print("=" * 70)
print("C. 报告结构检查（事实/推测/局限必须分区存在）")
print("=" * 70)
for needle in ["## 二、事实", "## 三、推测", "## 四、数据局限", "## 附录"]:
    ok = needle in report
    print(f"  [{'OK ' if ok else 'MISS'}] {needle}")
    if not ok:
        fails.append(needle)

# 禁止把推广直接说成原因：事实/结论区不得出现强因果断言；
# 允许在“禁止这样表述”的警示语中出现，但该行必须带否定标记。
banned = ["推广带来了", "推广导致", "延期导致收入减少", "推广使收入增长"]
neg_markers = ["不应", "不能", "勿", "无法", "非", "禁止"]
facts_section = report.split("## 二、事实")[1].split("## 三、推测")[0]
print()
for b in banned:
    in_facts = b in facts_section
    # 报告中所有出现该短语的行，必须带否定标记（说明是反例引用）
    bad_lines = [ln for ln in report.splitlines()
                 if b in ln and not any(mk in ln for mk in neg_markers)]
    ok = (not in_facts) and (not bad_lines)
    note = "事实区无强因果" if not in_facts else "事实区出现强因果!"
    if bad_lines:
        note += f"; 无否定标记的行: {bad_lines}"
    print(f"  [{'OK ' if ok else 'FAIL'}] {b:<20} {note}")
    if not ok:
        fails.append("banned:" + b)

print()
print("=" * 70)
print("D. 追加章节校验（管理层摘要 + 三项行动）")
print("=" * 70)

import re as _re

MM0, MM1 = "2026-09", "2026-10"
SEGS = sorted({(r["region"], r["product"]) for r in rows})


def _seg(month, s):
    rr = [x for x in rows if x["month"] == month and (x["region"], x["product"]) == s][0]
    rv, cs = D(rr["revenue"]), D(rr["cost"])
    return rv, cs, rv - cs


tot = {mm: m[mm]["rev"] for mm in (MM0, MM1)}
wts, mgn = {}, {}
for mm in (MM0, MM1):
    for s in SEGS:
        rv, cs, gp = _seg(mm, s)
        wts[(mm, s)] = rv / tot[mm]
        mgn[(mm, s)] = gp / rv
mix_eff = sum((((mgn[(MM0, s)] + mgn[(MM1, s)]) / 2) * (wts[(MM1, s)] - wts[(MM0, s)]) for s in SEGS))
rate_eff = sum((((wts[(MM0, s)] + wts[(MM1, s)]) / 2) * (mgn[(MM1, s)] - mgn[(MM0, s)]) for s in SEGS))

gp0 = m[MM0]["rev"] - m[MM0]["cost"]
gp1 = m[MM1]["rev"] - m[MM1]["cost"]
pct_set = set()
pp_set = set()
money_set = set()
for mm in (MM0, MM1):
    rev, cost = m[mm]["rev"], m[mm]["cost"]
    pct_set.add(round(abs((rev - cost) / rev * 100), 2))
    money_set |= {float(rev), float(cost), float(rev - cost)}
for a, b in ((MM0, MM1),):
    pct_set.add(round(abs((m[b]["rev"] - m[a]["rev"]) / m[a]["rev"] * 100), 2))
    pct_set.add(round(abs((m[b]["cost"] - m[a]["cost"]) / m[a]["cost"] * 100), 2))
    pct_set.add(round(abs((gp1 - gp0) / gp0 * 100), 2))
for s in SEGS:
    rv0, cs0, g0 = _seg(MM0, s)
    rv1, cs1, g1 = _seg(MM1, s)
    pct_set.add(round(abs((rv1 - rv0) / rv0 * 100), 2))
    pct_set.add(round(abs((g1 - g0) / g0 * 100), 2))
    pp_set.add(round(abs((g1 / rv1 - g0 / rv0) * 100), 2))
    money_set |= {float(rv0), float(cs0), float(g0), float(rv1), float(cs1), float(g1)}
pp_set.add(round(abs(mix_eff * 100), 2))
pp_set.add(round(abs(rate_eff * 100), 2))
pp_set.add(round(abs((gp1 / m[MM1]["rev"] - gp0 / m[MM0]["rev"]) * 100), 2))
pct_set.add(round(abs((m[MM0]["rev"] - m[MM0]["cost"]) / m[MM0]["rev"] * 100), 2))
pct_set.add(round(abs((m[MM1]["rev"] - m[MM1]["cost"]) / m[MM1]["rev"] * 100), 2))

pct_set = {float(x) for x in pct_set}
pp_set = {float(x) for x in pp_set}
money_set = {float(x) for x in money_set}

has_sec6 = "## 六、管理层摘要与下周行动" in report
print(f"  [{'OK ' if has_sec6 else 'MISS'}] 存在第六节")
if not has_sec6:
    fails.append("sec6")

sm = _re.search(r"### 6\.1 管理层摘要（正文 (\d+) 字，不含空白）\s*\n\s*>\s*(.+?)\n", report)
if sm:
    declared = int(sm.group(1))
    summary_txt = sm.group(2).strip()
    real = len(_re.sub(r"\s", "", summary_txt))
    ok = real <= 150 and declared == real
    print(f"  [{'OK ' if ok else 'FAIL'}] 摘要长度 声明={declared} 实测={real} (上限 150)")
    if not ok:
        fails.append("summary_len")
    for tok in _re.findall(r"[-+]?\d[\d,]*\.?\d*(?:%|pp)", summary_txt):
        unit = "pp" if tok.endswith("pp") else "%"
        num = abs(float(tok.rstrip("%pp")))
        pool = pp_set if unit == "pp" else pct_set
        hit = any(abs(num - v) < 0.005 for v in pool)
        print(f"  [{'OK ' if hit else 'FAIL'}] 摘要比率有出处: {tok}")
        if not hit:
            fails.append("summary_num:" + tok)
    for tok in _re.findall(r"\d[\d,]{3,}", summary_txt):
        num = float(tok.replace(",", ""))
        hit = any(abs(num - v) < 0.005 for v in money_set)
        print(f"  [{'OK ' if hit else 'FAIL'}] 摘要金额有出处: {tok}")
        if not hit:
            fails.append("summary_money:" + tok)
else:
    print("  [MISS] 未找到 6.1 摘要段落")
    fails.append("summary_missing")

act_part = report.split("### 6.2 下周三项行动")[-1]
acts = _re.findall(r"^\d+\. \*\*(.+?)\*\*", act_part, _re.M)
ok = len(acts) == 3
print(f"  [{'OK ' if ok else 'FAIL'}] 三项行动数量 = {len(acts)}: {acts}")
if not ok:
    fails.append("actions_count")
for b in banned:
    in_act = b in act_part
    print(f"  [{'OK ' if not in_act else 'FAIL'}] 行动区未出现强因果: {b}")
    if in_act:
        fails.append("actions_banned:" + b)

print()
print("=" * 70)
if fails:
    print(f"校验失败 {len(fails)} 项: {fails}")
    sys.exit(1)
print(f"全部基础校验 + 追加章节校验通过")
print("=" * 70)
