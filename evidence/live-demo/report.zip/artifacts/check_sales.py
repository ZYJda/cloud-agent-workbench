# -*- coding: utf-8 -*-
"""销售复盘核对脚本：对 uploads/c7d8986b-sales.csv 做精确核算与数据质量检查。
金额单位：人民币元（已去税费）。
"""
import csv
import os
import sys
from decimal import Decimal, ROUND_HALF_UP

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = os.path.join(BASE, "uploads", "c7d8986b-sales.csv")

D = Decimal


def pct(x):
    """比率(0.4371) -> 百分数字符串(43.71%)，保留 2 位小数。"""
    if x is None:
        return "n/a"
    return str((x * 100).quantize(D("0.01"), rounding=ROUND_HALF_UP)) + "%"


def money(x):
    return str(x.quantize(D("0.01"), rounding=ROUND_HALF_UP))


def ratio(n, d):
    return (n / d) if d != 0 else None


# ---------- 1. 读取 ----------
with open(CSV, "rb") as f:
    raw = f.read()
has_bom = raw.startswith(b"\xef\xbb\xbf")
has_crlf = b"\r\n" in raw
text = raw.decode("utf-8-sig")
reader = csv.DictReader(text.splitlines())
rows = list(reader)
fields = reader.fieldnames

print("=" * 72)
print("1. 数据载入")
print("=" * 72)
print(f"文件: {CSV}")
print(f"字节数: {len(raw)}  UTF-8 BOM: {has_bom}  CRLF行尾: {has_crlf}")
print(f"列: {fields}")
print(f"数据行数: {len(rows)}")
for r in rows:
    print("   ", r)

# ---------- 2. 数据质量检查 ----------
print()
print("=" * 72)
print("2. 数据质量检查")
print("=" * 72)

# 2.1 完整性：月份 x 区域 x 产品 的组合是否齐全
months = sorted({r["month"] for r in rows})
regions = sorted({r["region"] for r in rows})
products = sorted({r["product"] for r in rows})
present = {(r["month"], r["region"], r["product"]) for r in rows}
missing = [
    (m, reg, p)
    for m in months for reg in regions for p in products
    if (m, reg, p) not in present
]
print(f"月份: {months}")
print(f"区域: {regions}")
print(f"产品: {products}")
print(f"应有组合数 {len(months)*len(regions)*len(products)}，实际 {len(present)}")
print(f"缺失组合: {missing if missing else '无'}")

# 2.2 重复行检查
keys = [(r["month"], r["region"], r["product"]) for r in rows]
dups = {k for k in keys if keys.count(k) > 1}
print(f"重复主键: {dups if dups else '无'}")

# 2.3 数值合法性 & 成本率检查
print("\n逐行核验 (revenue-cost=gross_profit, cost/revenue):")
for r in rows:
    rev, cost = D(r["revenue"]), D(r["cost"])
    gp = rev - cost
    cr = ratio(cost, rev)
    print(
        f"  {r['month']} {r['region']:>4} {r['product']:>4} "
        f"rev={money(rev):>9} cost={money(cost):>9} gp={money(gp):>9} "
        f"gm={pct(ratio(gp, rev)):>8} cost/rev={pct(cr):>8}"
    )

# 2.4 是否含销量/单价/推广费用等字段
extra = [k for k in fields if k not in ("month", "region", "product", "revenue", "cost")]
print(f"\n缺失的分析字段(相对本次复盘需要): 销量/单价 -> 无；推广费用 -> 无；客户级明细 -> 无")
print(f"实际存在的额外字段: {extra if extra else '无'}")

# ---------- 3. 月度汇总 ----------
print()
print("=" * 72)
print("3. 月度汇总与环比")
print("=" * 72)

agg = {}
for m in months:
    rev = sum((D(r["revenue"]) for r in rows if r["month"] == m), D(0))
    cost = sum((D(r["cost"]) for r in rows if r["month"] == m), D(0))
    agg[m] = {"revenue": rev, "cost": cost, "gp": rev - cost, "gm": ratio(rev - cost, rev)}

m0, m1 = months[0], months[-1]
for m in months:
    a = agg[m]
    print(f"{m}: 收入={money(a['revenue'])} 成本={money(a['cost'])} "
          f"毛利={money(a['gp'])} 毛利率={pct(a['gm'])}")

a0, a1 = agg[m0], agg[m1]
d_rev = a1["revenue"] - a0["revenue"]
d_cost = a1["cost"] - a0["cost"]
d_gp = a1["gp"] - a0["gp"]
d_gm_pp = (a1["gm"] - a0["gm"]) * 100
d_gm_rel = (a1["gm"] - a0["gm"]) / a0["gm"]

print(f"\n环比 {m0} -> {m1}")
print(f"  收入: {money(a0['revenue'])} -> {money(a1['revenue'])}  变动 {money(d_rev)}  "
      f"环比 {pct(d_rev / a0['revenue'])}")
print(f"  成本: {money(a0['cost'])} -> {money(a1['cost'])}  变动 {money(d_cost)}  "
      f"环比 {pct(d_cost / a0['cost'])}")
print(f"  毛利: {money(a0['gp'])} -> {money(a1['gp'])}  变动 {money(d_gp)}  "
      f"环比 {pct(d_gp / a0['gp'])}")
print(f"  毛利率: {pct(a0['gm'])} -> {pct(a1['gm'])}  变动 {d_gm_pp.quantize(D('0.01'), rounding=ROUND_HALF_UP)} 个百分点 "
      f"(相对变动 {pct(d_gm_rel)})")
print(f"  成本增速 {pct(d_cost / a0['cost'])} vs 收入增速 {pct(d_rev / a0['revenue'])} "
      f"-> 成本增速{'低于' if d_cost / a0['cost'] < d_rev / a0['revenue'] else '高于'}收入增速")

# ---------- 4. 分部拆解 ----------
print()
print("=" * 72)
print("4. 分部（区域 x 产品）拆解")
print("=" * 72)
seg = {}
for r in rows:
    k = (r["region"], r["product"])
    seg.setdefault(k, {})[r["month"]] = {
        "revenue": D(r["revenue"]), "cost": D(r["cost"]),
        "gp": D(r["revenue"]) - D(r["cost"]),
    }
for k in sorted(seg):
    s0, s1 = seg[k][m0], seg[k][m1]
    gm0 = ratio(s0["gp"], s0["revenue"])
    gm1 = ratio(s1["gp"], s1["revenue"])
    print(f"\n{k[0]} / {k[1]}")
    print(f"  收入 {money(s0['revenue'])} -> {money(s1['revenue'])}  变动 {money(s1['revenue'] - s0['revenue'])} "
          f"({pct((s1['revenue'] - s0['revenue']) / s0['revenue'])})")
    print(f"  毛利 {money(s0['gp'])} -> {money(s1['gp'])}  变动 {money(s1['gp'] - s0['gp'])} "
          f"({pct((s1['gp'] - s0['gp']) / s0['gp'])})")
    print(f"  毛利率 {pct(gm0)} -> {pct(gm1)}  变动 "
          f"{(gm1 - gm0) * 100:.2f} 个百分点")

# ---------- 5. 毛利率变动的“价/量/结构”分解 ----------
print()
print("=" * 72)
print("5. 毛利率环比变动的结构分解（权重=收入占比）")
print("=" * 72)
w = {}
for m in months:
    tot = agg[m]["revenue"]
    for k in sorted(seg):
        if m in seg[k]:
            w[(m, k)] = ratio(seg[k][m]["revenue"], tot)
mg = {}
for m in months:
    for k in sorted(seg):
        if m in seg[k]:
            s = seg[k][m]
            mg[(m, k)] = ratio(s["gp"], s["revenue"])

rate = mix = D(0)
print("\n分部 | 9月收入权重 | 9月毛利率 | 10月收入权重 | 10月毛利率")
for k in sorted(seg):
    w0, w1 = w[(m0, k)], w[(m1, k)]
    m0r, m1r = mg[(m0, k)], mg[(m1, k)]
    print(f"{k[0]}/{k[1]} | {pct(w0)} | {pct(m0r)} | {pct(w1)} | {pct(m1r)}")
    # 对称分解：ΔGM = Σ w̄·Δm + Σ m̄·Δw，两项相加严格等于总变动（交互项已抵消）
    rate += ((w0 + w1) / 2) * (m1r - m0r)
    mix += ((m0r + m1r) / 2) * (w1 - w0)

total_gm_change = a1["gm"] - a0["gm"]
print(f"\n合计毛利率变动: {total_gm_change * 100:.2f} 个百分点")
print(f"  结构效应(收入结构变化): {mix * 100:.2f} pp")
print(f"  分部毛利率效应(各分部自身毛利率变化): {rate * 100:.2f} pp")
print(f"  校验合计: {(mix + rate) * 100:.4f} pp "
      f"(残差 {(total_gm_change - mix - rate) * 100:.8f} pp，应为 0)")

# ---------- 6. 贡献度分解（毛利增量来自哪里） ----------
print()
print("=" * 72)
print("6. 毛利增量归因（对总毛利变动 +{} 的贡献）".format(money(d_gp)))
print("=" * 72)
tot_contrib = D(0)
for k in sorted(seg):
    c = seg[k][m1]["gp"] - seg[k][m0]["gp"]
    tot_contrib += c
    print(f"  {k[0]}/{k[1]}: 贡献 {money(c)}  占总增量 {pct(ratio(c, d_gp))}")
print(f"  合计 {money(tot_contrib)}  (与总毛利变动 {money(d_gp)} 一致: {tot_contrib == d_gp})")

print(f"\n收入增量归因（对总收入变动 +{money(d_rev)} 的贡献）")
tot_rc = D(0)
for k in sorted(seg):
    c = seg[k][m1]["revenue"] - seg[k][m0]["revenue"]
    tot_rc += c
    print(f"  {k[0]}/{k[1]}: 贡献 {money(c)}  占总增量 {pct(ratio(c, d_rev))}")
print(f"  合计 {money(tot_rc)}  (与总收入变动 {money(d_rev)} 一致: {tot_rc == d_rev})")

# ---------- 7. 集中度与成本率结构检查 ----------
print()
print("=" * 72)
print("7. 集中度与成本率结构检查")
print("=" * 72)

reg_rev = {}
for m in months:
    for reg in regions:
        reg_rev[(m, reg)] = sum(
            (seg[(reg, p)][m]["revenue"] for p in products
             if (reg, p) in seg and m in seg[(reg, p)]), D(0))

print("\n7.1 区域集中度（各区域占当月收入比重）")
for m in months:
    parts = [f"{reg} {pct(ratio(reg_rev[(m, reg)], agg[m]['revenue']))}" for reg in regions]
    print(f"  {m}: " + " | ".join(parts))

print("\n7.2 各行成本率是否为整数百分比")
all_round = True
for r in rows:
    cr = ratio(D(r["cost"]), D(r["revenue"]))
    is_round = (cr * 100) == (cr * 100).to_integral_value()
    all_round = all_round and is_round
    print(f"  {r['month']} {r['region']} {r['product']}: 成本率 {pct(cr)} -> 整数百分比: {is_round}")
print(f"  全部 6 行成本率均为整数百分比: {all_round}")

print("\n7.3 量价拆分可行性")
print("  本表无销量/单价字段，收入变动无法拆分为'量'与'价'；10 月收入 +8000 元仅为总额差额。")

# ---------- 8. 一致性交叉校验 ----------
print()
print("=" * 72)
print("8. 独立交叉校验（用另一套口径重算，验证结果一致）")
print("=" * 72)
# 7.1 用 Decimal 重算 total == sum(parts) 的另一种路径
alt_rev = {m: D(0) for m in months}
alt_cost = {m: D(0) for m in months}
for r in rows:
    alt_rev[r["month"]] += D(r["revenue"])
    alt_cost[r["month"]] += D(r["cost"])
ok_rev = all(alt_rev[m] == agg[m]["revenue"] for m in months)
ok_cost = all(alt_cost[m] == agg[m]["cost"] for m in months)
print(f"总收入重算一致: {ok_rev}; 总成本重算一致: {ok_cost}")

# 7.2 手工算术验证 9 月
chk9_rev = D(36000) + D(24000) + D(10000)
chk9_cost = D(18000) + D(14400) + D(7000)
print(f"9月 手工核对: 收入 {money(chk9_rev)} (期望 70000) 成本 {money(chk9_cost)} (期望 39400) "
      f"毛利 {money(chk9_rev - chk9_cost)} (期望 30600) 毛利率 "
      f"{pct(D(30600) / D(70000))} (期望 43.71%)")
chk10_rev = D(45000) + D(21000) + D(12000)
chk10_cost = D(20250) + D(13650) + D(8400)
print(f"10月 手工核对: 收入 {money(chk10_rev)} (期望 78000) 成本 {money(chk10_cost)} (期望 42300) "
      f"毛利 {money(chk10_rev - chk10_cost)} (期望 35700) 毛利率 "
      f"{pct(D(35700) / D(78000))} (期望 45.77%)")

# 7.3 环比百分比的独立验算
print(f"环比收入校验: (78000-70000)/70000 = {pct(D(8000) / D(70000))} (期望 11.43%)")
print(f"环比成本校验: (42300-39400)/39400 = {pct(D(2900) / D(39400))} (期望 7.36%)")
print(f"环比毛利校验: (35700-30600)/30600 = {pct(D(5100) / D(30600))} (期望 16.67%)")

# 7.4 加总检验：所有分部毛利之和是否等于月度毛利
for m in months:
    s = sum((seg[k][m]["gp"] for k in seg if m in seg[k]), D(0))
    print(f"{m} 分部毛利求和 {money(s)} == 月度毛利 {money(agg[m]['gp'])}: {s == agg[m]['gp']}")

print("\n" + "=" * 72)
print("核对完成")
print("=" * 72)

