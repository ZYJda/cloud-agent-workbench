#!/usr/bin/env python3
"""按 category 列汇总 amount 列的 CSV 命令行工具。

仅依赖 Python 标准库（csv / decimal / argparse 等），无需安装任何第三方包。

示例：
    python summary.py sales.csv
    python summary.py sales.csv -c 类别 -a 金额 -o 汇总.csv
    type sales.csv | python summary.py -
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable, Iterator, Mapping, Sequence, TextIO

__all__ = [
    "DEFAULT_AMOUNT_COLUMN",
    "DEFAULT_CATEGORY_COLUMN",
    "EMPTY_CATEGORY_LABEL",
    "SummaryError",
    "SummaryResult",
    "detect_delimiter",
    "format_amount",
    "main",
    "parse_amount",
    "render_csv",
    "render_json",
    "render_table",
    "summarize_file",
    "summarize_rows",
    "summarize_stream",
]

DEFAULT_CATEGORY_COLUMN = "category"
DEFAULT_AMOUNT_COLUMN = "amount"
EMPTY_CATEGORY_LABEL = "(空)"

_CURRENCY_SYMBOLS = "¥$€£₤₩₫₽฿"
_IGNORED_CHARS = re.compile(r"[,\s\u00a0\u3000_\u200b]")
_HEADER_NOISE = re.compile(r"[\s_\-]+")
_DELIMITER_CANDIDATES = ",;\t|"


class SummaryError(Exception):
    """输入数据或参数不符合预期时抛出。"""


@dataclass(frozen=True)
class SkippedRow:
    """被跳过的数据行及其原因。"""

    line: int
    reason: str


@dataclass
class SummaryResult:
    """汇总结果：每个分类的金额合计，以及处理过程中的统计信息。"""

    totals: dict[str, Decimal] = field(default_factory=dict)
    row_counts: dict[str, int] = field(default_factory=dict)
    valid_rows: int = 0
    skipped_rows: list[SkippedRow] = field(default_factory=list)

    @property
    def skipped_count(self) -> int:
        return len(self.skipped_rows)

    @property
    def grand_total(self) -> Decimal:
        return sum(self.totals.values(), Decimal("0"))

    def sorted_items(self, sort: str = "total", reverse: bool = False) -> list[tuple[str, Decimal]]:
        """按指定规则返回 (分类, 合计) 列表。

        ``sort="total"`` 的规范顺序是金额从大到小（同额按分类名正序），
        ``sort="category"`` 的规范顺序是分类名正序；``reverse=True`` 表示反向。
        """
        items = list(self.totals.items())
        if sort == "category":
            items.sort(key=lambda item: (item[0].casefold(), item[0]), reverse=reverse)
        elif sort == "total":
            if reverse:
                items.sort(key=lambda item: (item[1], item[0].casefold(), item[0]))
            else:
                items.sort(key=lambda item: (-item[1], item[0].casefold(), item[0]))
        else:
            raise SummaryError(f"未知的排序方式: {sort}")
        return items


def parse_amount(raw: object) -> Decimal:
    """把单元格文本解析为 Decimal 金额，失败时抛出 ValueError。

    支持的写法：``1234.56``、``¥1,234.56``、``-12.5``、``(12.5)``（会计负数）、
    ``12.5-``（尾随负号）、``+8``、带千分位或空格的数字。
    """
    if raw is None:
        raise ValueError("金额为空")
    if isinstance(raw, Decimal):
        return raw
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        return Decimal(str(raw))

    text = str(raw).strip()
    if not text:
        raise ValueError("金额为空")

    parenthesized = text.startswith("(") and text.endswith(")")
    if parenthesized:
        text = text[1:-1].strip()

    for symbol in _CURRENCY_SYMBOLS:
        text = text.replace(symbol, "")
    text = text.strip()
    if not text:
        raise ValueError("金额为空")

    sign = 1
    if text.startswith("-"):
        sign = -1
        text = text[1:].strip()
    elif text.startswith("+"):
        text = text[1:].strip()
    elif text.endswith("-"):
        sign = -1
        text = text[:-1].strip()

    text = _IGNORED_CHARS.sub("", text)
    if not text:
        raise ValueError("金额为空")

    try:
        value = Decimal(text)
    except (InvalidOperation, ValueError):
        raise ValueError(f"无法解析的金额: {raw!r}") from None

    if parenthesized:
        sign = -1
    return -value.copy_abs() if sign < 0 else value


def format_amount(value: Decimal) -> str:
    """把 Decimal 金额格式化为普通十进制字符串（不使用科学计数法）。"""
    if value == value.to_integral_value() and value.as_tuple().exponent == 0:
        return str(value.quantize(Decimal("1")))
    return format(value, "f")


def detect_delimiter(sample: str) -> str:
    """从样本文本猜测 CSV 分隔符，失败时回退为逗号。"""
    if not sample.strip():
        return ","
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=_DELIMITER_CANDIDATES)
    except csv.Error:
        counts = {delimiter: sample.count(delimiter) for delimiter in _DELIMITER_CANDIDATES}
        best = max(counts, key=lambda key: counts[key])
        return best if counts[best] > 0 else ","
    return dialect.delimiter


def _normalize_header(name: object) -> str:
    return _HEADER_NOISE.sub("", str(name or "")).casefold()


def resolve_column(fieldnames: Sequence[str | None], requested: str, role: str) -> str:
    """在表头中定位目标列，允许大小写/空格差异与唯一子串匹配。"""
    if not fieldnames:
        raise SummaryError("CSV 缺少表头行，无法定位列名")
    normalized = {_normalize_header(name): name for name in fieldnames if name is not None}
    key = _normalize_header(requested)
    if key in normalized:
        return str(normalized[key])
    candidates = [str(original) for norm, original in normalized.items() if key and key in norm]
    if len(candidates) == 1:
        return candidates[0]
    available = ", ".join(str(name) for name in fieldnames if name is not None)
    raise SummaryError(f"找不到{role}列 {requested!r}；CSV 中的列: {available}")


def summarize_rows(
    rows: Iterable[Mapping[str, object]],
    category_column: str = DEFAULT_CATEGORY_COLUMN,
    amount_column: str = DEFAULT_AMOUNT_COLUMN,
    *,
    fieldnames: Sequence[str | None] | None = None,
    strict: bool = False,
) -> SummaryResult:
    """对已经读入内存的行做分类汇总。"""
    head, body = itertools.tee(iter(rows))
    first_row = next(head, None)
    if fieldnames is None:
        fieldnames = list(first_row.keys()) if first_row else []

    category_key = resolve_column(fieldnames, category_column, "分类")
    amount_key = resolve_column(fieldnames, amount_column, "金额")

    totals: dict[str, Decimal] = {}
    row_counts: dict[str, int] = {}
    skipped: list[SkippedRow] = []
    valid_rows = 0

    for offset, row in enumerate(body, start=2):
        if row is None:
            continue
        values = list(row.values())
        if not any(str(value).strip() for value in values if value is not None):
            continue
        category = str(row.get(category_key) or "").strip()
        if not category:
            category = EMPTY_CATEGORY_LABEL
        try:
            amount = parse_amount(row.get(amount_key))
        except ValueError as exc:
            if strict:
                raise SummaryError(f"第 {offset} 行金额无效: {exc}") from None
            skipped.append(SkippedRow(offset, str(exc)))
            continue
        totals[category] = totals.get(category, Decimal("0")) + amount
        row_counts[category] = row_counts.get(category, 0) + 1
        valid_rows += 1

    return SummaryResult(
        totals=totals,
        row_counts=row_counts,
        valid_rows=valid_rows,
        skipped_rows=skipped,
    )


def summarize_stream(
    stream: TextIO,
    category_column: str = DEFAULT_CATEGORY_COLUMN,
    amount_column: str = DEFAULT_AMOUNT_COLUMN,
    *,
    delimiter: str | None = None,
    strict: bool = False,
) -> SummaryResult:
    """从已打开的文本流汇总（自动识别分隔符）。"""
    # 按整行取样，既能嗅探分隔符，又不会破坏行边界（管道输入不可回退）。
    sampled_lines: list[str] = []
    sampled_chars = 0
    for line in stream:
        sampled_lines.append(line)
        sampled_chars += len(line)
        if sampled_chars >= 8192:
            break
    sample = "".join(sampled_lines)
    if delimiter is None:
        delimiter = detect_delimiter(sample)
    reader = csv.DictReader(itertools.chain(sampled_lines, stream), delimiter=delimiter)
    return summarize_rows(
        reader,
        category_column,
        amount_column,
        fieldnames=reader.fieldnames or [],
        strict=strict,
    )


def summarize_file(
    path: str | Path,
    category_column: str = DEFAULT_CATEGORY_COLUMN,
    amount_column: str = DEFAULT_AMOUNT_COLUMN,
    *,
    delimiter: str | None = None,
    encoding: str = "utf-8-sig",
    strict: bool = False,
) -> SummaryResult:
    """从 CSV 文件路径汇总。"""
    file_path = Path(path)
    if not file_path.exists():
        raise SummaryError(f"文件不存在: {file_path}")
    try:
        with file_path.open("r", encoding=encoding, newline="") as handle:
            return summarize_stream(
                handle,
                category_column,
                amount_column,
                delimiter=delimiter,
                strict=strict,
            )
    except UnicodeDecodeError as exc:
        raise SummaryError(f"无法以 {encoding} 解码文件 {file_path}: {exc}") from None


class _ListWriter:
    """极简的可写对象，用于把 csv.writer 的输出收集到列表中。"""

    def __init__(self, buffer: list[str]) -> None:
        self._buffer = buffer

    def write(self, text: str) -> int:
        self._buffer.append(text)
        return len(text)


def render_csv(
    result: SummaryResult,
    *,
    sort: str = "total",
    reverse: bool = False,
    header: bool = True,
    category_name: str = DEFAULT_CATEGORY_COLUMN,
    amount_name: str = "total",
) -> str:
    """把汇总结果渲染为 CSV 文本。"""
    buffer: list[str] = []
    writer = csv.writer(_ListWriter(buffer), lineterminator="\n")
    if header:
        writer.writerow([category_name, amount_name])
    for category, total in result.sorted_items(sort, reverse):
        writer.writerow([category, format_amount(total)])
    return "".join(buffer)


def render_json(
    result: SummaryResult,
    *,
    sort: str = "total",
    reverse: bool = False,
    indent: int = 2,
) -> str:
    """把汇总结果渲染为 JSON 文本。

    金额一律以字符串输出，避免 JSON 数字的双精度舍入丢失精度；
    ``categories`` 沿用与 CSV/表格输出相同的排序规则。
    """
    payload = {
        "grand_total": format_amount(result.grand_total),
        "valid_rows": result.valid_rows,
        "skipped_rows": result.skipped_count,
        "categories": [
            {
                "category": category,
                "total": format_amount(total),
                "rows": result.row_counts.get(category, 0),
            }
            for category, total in result.sorted_items(sort, reverse)
        ],
        "skipped": [
            {"line": row.line, "reason": row.reason}
            for row in result.skipped_rows
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=indent)


def render_table(result: SummaryResult, *, sort: str = "total", reverse: bool = False) -> str:
    """把汇总结果渲染为对齐的文本表格。"""
    items = result.sorted_items(sort, reverse)
    if not items:
        return "(没有可汇总的数据行)"
    name_width = max(len("category"), *(len(name) for name, _ in items))
    amount_width = max(len("total"), *(len(format_amount(total)) for _, total in items))
    lines = [f"{'category'.ljust(name_width)}  {'total'.rjust(amount_width)}"]
    lines.append(f"{'-' * name_width}  {'-' * amount_width}")
    for name, total in items:
        lines.append(f"{name.ljust(name_width)}  {format_amount(total).rjust(amount_width)}")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="summary.py",
        description="按 category 列汇总 amount 列，输出每个分类的金额合计。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python summary.py sales.csv\n"
            "  python summary.py sales.csv -c 类别 -a 金额 -o 汇总.csv\n"
            "  python summary.py sales.csv --format table --sort category\n"
            "  type sales.csv | python summary.py -\n"
        ),
    )
    parser.add_argument("input", help="输入 CSV 文件路径，使用 - 表示从标准输入读取")
    parser.add_argument("-c", "--category-column", default=DEFAULT_CATEGORY_COLUMN, help="分类列名（默认: category）")
    parser.add_argument("-a", "--amount-column", default=DEFAULT_AMOUNT_COLUMN, help="金额列名（默认: amount）")
    parser.add_argument("-d", "--delimiter", default=None, help="CSV 分隔符，默认自动识别")
    parser.add_argument("--encoding", default="utf-8-sig", help="输入文件编码（默认: utf-8-sig，兼容带 BOM 的 UTF-8）")
    parser.add_argument("-o", "--output", default=None, help="输出文件路径，默认写入标准输出")
    parser.add_argument("--format", choices=("csv", "table"), default="csv", help="输出格式: csv 或 table（默认: csv）")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出（优先于 --format）")
    parser.add_argument("--sort", choices=("total", "category"), default="total", help="排序依据: total 或 category（默认: total）")
    parser.add_argument("--reverse", action="store_true", help="反向排序（金额从小到大 / 分类名 Z→A）")
    parser.add_argument("--no-header", action="store_true", help="输出中不包含表头")
    parser.add_argument("--strict", action="store_true", help="遇到无效金额立即报错，而不是跳过该行")
    parser.add_argument("-q", "--quiet", action="store_true", help="不在标准错误输出警告信息")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    reverse = args.reverse

    try:
        if args.input == "-":
            result = summarize_stream(
                sys.stdin,
                args.category_column,
                args.amount_column,
                delimiter=args.delimiter,
                strict=args.strict,
            )
        else:
            result = summarize_file(
                args.input,
                args.category_column,
                args.amount_column,
                delimiter=args.delimiter,
                encoding=args.encoding,
                strict=args.strict,
            )
    except SummaryError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"错误: 无法读取 {args.input}: {exc}", file=sys.stderr)
        return 2

    if result.skipped_rows and not args.quiet:
        lines = ", ".join(str(row.line) for row in result.skipped_rows)
        print(f"警告: 已跳过 {result.skipped_count} 行无效金额（第 {lines} 行）", file=sys.stderr)

    if args.json:
        text = render_json(result, sort=args.sort, reverse=reverse)
    elif args.format == "table":
        text = render_table(result, sort=args.sort, reverse=reverse)
    else:
        text = render_csv(result, sort=args.sort, reverse=reverse, header=not args.no_header)
    text = text.rstrip("\n")

    if args.output:
        output_path = Path(args.output)
        try:
            if output_path.parent != Path(""):
                output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            print(f"错误: 无法写入 {args.output}: {exc}", file=sys.stderr)
            return 2
    else:
        print(text)

    return 0


if __name__ == "__main__":
    sys.exit(main())
