"""summary.py 的单元测试。

运行方式：
    python -m unittest discover -s artifacts -v
    python artifacts/test_summary.py -v
"""

from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import summary  # noqa: E402


class ParseAmountTests(unittest.TestCase):
    """金额文本解析。"""

    def test_plain_numbers(self) -> None:
        self.assertEqual(summary.parse_amount("12.5"), Decimal("12.5"))
        self.assertEqual(summary.parse_amount("  30 "), Decimal("30"))
        self.assertEqual(summary.parse_amount("0"), Decimal("0"))

    def test_currency_and_thousand_separators(self) -> None:
        self.assertEqual(summary.parse_amount("¥1,234.50"), Decimal("1234.50"))
        self.assertEqual(summary.parse_amount("$2,000"), Decimal("2000"))
        self.assertEqual(summary.parse_amount("1 234.56"), Decimal("1234.56"))

    def test_negative_forms(self) -> None:
        self.assertEqual(summary.parse_amount("-12.5"), Decimal("-12.5"))
        self.assertEqual(summary.parse_amount("(12.5)"), Decimal("-12.5"))
        self.assertEqual(summary.parse_amount("12.5-"), Decimal("-12.5"))
        self.assertEqual(summary.parse_amount("+8"), Decimal("8"))

    def test_invalid_values_raise(self) -> None:
        for raw in ("", "   ", None, "abc", "1.2.3"):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    summary.parse_amount(raw)


class SummarizeRowsTests(unittest.TestCase):
    """内存中的行汇总。"""

    def test_groups_amounts_by_category(self) -> None:
        rows = [
            {"category": "食品", "amount": "10.50"},
            {"category": "交通", "amount": "3"},
            {"category": "食品", "amount": "4.25"},
            {"category": "交通", "amount": "1.5"},
        ]
        result = summary.summarize_rows(rows)
        self.assertEqual(result.totals["食品"], Decimal("14.75"))
        self.assertEqual(result.totals["交通"], Decimal("4.5"))
        self.assertEqual(result.valid_rows, 4)
        self.assertEqual(result.skipped_count, 0)
        self.assertEqual(result.grand_total, Decimal("19.25"))

    def test_invalid_rows_are_skipped_and_counted(self) -> None:
        rows = [
            {"category": "食品", "amount": "10"},
            {"category": "损坏", "amount": "N/A"},
            {"category": "交通", "amount": ""},
            {"category": "食品", "amount": "5"},
        ]
        result = summary.summarize_rows(rows)
        self.assertEqual(result.totals, {"食品": Decimal("15")})
        self.assertEqual(result.valid_rows, 2)
        self.assertEqual(result.skipped_count, 2)
        self.assertEqual([row.line for row in result.skipped_rows], [3, 4])

    def test_strict_mode_raises_on_invalid_amount(self) -> None:
        rows = [{"category": "食品", "amount": "oops"}]
        with self.assertRaises(summary.SummaryError):
            summary.summarize_rows(rows, strict=True)

    def test_blank_category_is_labelled(self) -> None:
        rows = [{"category": "  ", "amount": "5"}, {"category": "食品", "amount": "1"}]
        result = summary.summarize_rows(rows)
        self.assertIn(summary.EMPTY_CATEGORY_LABEL, result.totals)
        self.assertEqual(result.totals[summary.EMPTY_CATEGORY_LABEL], Decimal("5"))

    def test_header_matching_ignores_case_and_spaces(self) -> None:
        rows = [{"Category Name": "食品", "Amount": "12"}]
        result = summary.summarize_rows(rows, "category name", "amount")
        self.assertEqual(result.totals["食品"], Decimal("12"))

    def test_missing_column_raises(self) -> None:
        rows = [{"category": "食品", "amount": "12"}]
        with self.assertRaises(summary.SummaryError):
            summary.summarize_rows(rows, amount_column="price")

    def test_sorted_items_orders_by_total_and_category(self) -> None:
        result = summary.SummaryResult(
            totals={"A": Decimal("1"), "B": Decimal("10"), "C": Decimal("10")}
        )
        by_total = result.sorted_items("total")
        self.assertEqual([name for name, _ in by_total], ["B", "C", "A"])
        by_category = result.sorted_items("category")
        self.assertEqual([name for name, _ in by_category], ["A", "B", "C"])
        self.assertEqual(
            [name for name, _ in result.sorted_items("total", reverse=True)],
            ["A", "B", "C"],
        )


class SummarizeFileTests(unittest.TestCase):
    """文件与流输入。"""

    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tempdir.cleanup)
        self.dir = Path(self.tempdir.name)

    def write(self, name: str, text: str, encoding: str = "utf-8") -> Path:
        path = self.dir / name
        path.write_text(text, encoding=encoding)
        return path

    def test_reads_csv_file(self) -> None:
        path = self.write("sales.csv", "category,amount\n食品,10\n食品,5\n交通,2\n")
        result = summary.summarize_file(path)
        self.assertEqual(result.totals["食品"], Decimal("15"))
        self.assertEqual(result.totals["交通"], Decimal("2"))

    def test_handles_utf8_bom(self) -> None:
        path = self.dir / "bom.csv"
        path.write_text("category,amount\n食品,10\n", encoding="utf-8-sig")
        result = summary.summarize_file(path)
        self.assertEqual(result.totals["食品"], Decimal("10"))

    def test_detects_semicolon_delimiter(self) -> None:
        path = self.write("eu.csv", "category;amount\n食品;10\n食品;5\n")
        result = summary.summarize_file(path)
        self.assertEqual(result.totals["食品"], Decimal("15"))

    def test_custom_column_names(self) -> None:
        path = self.write("cn.csv", "类别,金额\n食品,10\n")
        result = summary.summarize_file(path, "类别", "金额")
        self.assertEqual(result.totals["食品"], Decimal("10"))

    def test_missing_file_raises(self) -> None:
        with self.assertRaises(summary.SummaryError):
            summary.summarize_file(self.dir / "nope.csv")

    def test_header_only_file_yields_empty_result(self) -> None:
        path = self.write("empty.csv", "category,amount\n")
        result = summary.summarize_file(path)
        self.assertEqual(result.totals, {})
        self.assertEqual(result.valid_rows, 0)

    def test_render_csv_and_table(self) -> None:
        result = summary.SummaryResult(totals={"食品": Decimal("15"), "交通": Decimal("2")})
        csv_text = summary.render_csv(result)
        self.assertEqual(csv_text, "category,total\n食品,15\n交通,2\n")
        table = summary.render_table(result)
        self.assertIn("category", table)
        self.assertIn("食品", table)


class CommandLineTests(unittest.TestCase):
    """端到端命令行行为。"""

    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tempdir.cleanup)
        self.dir = Path(self.tempdir.name)
        self.script = SCRIPT_DIR / "summary.py"

    def run_cli(self, *args: str, stdin: str | None = None) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        return subprocess.run(
            [sys.executable, str(self.script), *args],
            input=stdin,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=env,
            cwd=str(self.dir),
        )

    def test_cli_prints_summary_to_stdout(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n交通,2\n食品,5\n", encoding="utf-8")
        result = self.run_cli("sales.csv")
        self.assertEqual(result.returncode, 0, result.stderr)
        rows = list(csv.reader(io.StringIO(result.stdout)))
        self.assertEqual(rows, [["category", "total"], ["食品", "15"], ["交通", "2"]])

    def test_cli_writes_output_file(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n交通,2\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "-o", "out/summary.csv")
        self.assertEqual(result.returncode, 0, result.stderr)
        written = (self.dir / "out" / "summary.csv").read_text(encoding="utf-8")
        self.assertIn("食品,10", written)
        self.assertIn("交通,2", written)

    def test_cli_reads_stdin(self) -> None:
        result = self.run_cli("-", stdin="category,amount\n食品,4\n")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("食品,4", result.stdout)

    def test_cli_reports_invalid_amounts_on_stderr(self) -> None:
        source = self.dir / "dirty.csv"
        source.write_text("category,amount\n食品,10\n坏行,x\n", encoding="utf-8")
        result = self.run_cli("dirty.csv")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("警告", result.stderr)
        self.assertIn("食品,10", result.stdout)

    def test_cli_returns_error_code_for_unknown_column(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "-a", "price")
        self.assertEqual(result.returncode, 2)
        self.assertIn("错误", result.stderr)

    def test_cli_strict_mode_fails_on_invalid_amount(self) -> None:
        source = self.dir / "dirty.csv"
        source.write_text("category,amount\n坏行,x\n", encoding="utf-8")
        result = self.run_cli("dirty.csv", "--strict")
        self.assertEqual(result.returncode, 2)
        self.assertIn("无效", result.stderr)

    def test_cli_table_format_and_sorting(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n交通,2\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "--format", "table", "--sort", "category")
        self.assertEqual(result.returncode, 0, result.stderr)
        lines = [line for line in result.stdout.splitlines() if line.strip()]
        self.assertTrue(lines[0].startswith("category"))
        self.assertTrue(lines[2].startswith("交通"))
        self.assertTrue(lines[3].startswith("食品"))


class JsonOutputTests(unittest.TestCase):
    """JSON 输出。"""

    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(self.tempdir.cleanup)
        self.dir = Path(self.tempdir.name)
        self.script = SCRIPT_DIR / "summary.py"

    def run_cli(self, *args: str, stdin: str | None = None) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        return subprocess.run(
            [sys.executable, str(self.script), *args],
            input=stdin,
            capture_output=True,
            text=True,
            encoding="utf-8",
            env=env,
            cwd=str(self.dir),
        )

    def test_render_json_structure_and_amount_precision(self) -> None:
        result = summary.SummaryResult(
            totals={"餐饮": Decimal("1234.56"), "食品": Decimal("214.40")},
            row_counts={"餐饮": 1, "食品": 2},
            valid_rows=3,
        )
        payload = json.loads(summary.render_json(result))
        self.assertEqual(payload["grand_total"], "1448.96")
        self.assertEqual(payload["valid_rows"], 3)
        self.assertEqual(payload["skipped_rows"], 0)
        self.assertEqual(payload["skipped"], [])
        self.assertEqual(
            payload["categories"],
            [
                {"category": "餐饮", "total": "1234.56", "rows": 1},
                {"category": "食品", "total": "214.40", "rows": 2},
            ],
        )
        for entry in payload["categories"]:
            self.assertIsInstance(entry["total"], str)

    def test_render_json_includes_skipped_rows(self) -> None:
        result = summary.SummaryResult(
            totals={"食品": Decimal("10")},
            row_counts={"食品": 1},
            valid_rows=1,
            skipped_rows=[summary.SkippedRow(8, "无法解析的金额: '待确认'")],
        )
        payload = json.loads(summary.render_json(result))
        self.assertEqual(payload["skipped_rows"], 1)
        self.assertEqual(payload["skipped"], [{"line": 8, "reason": "无法解析的金额: '待确认'"}])

    def test_render_json_respects_sort_and_reverse(self) -> None:
        result = summary.SummaryResult(
            totals={"A": Decimal("1"), "B": Decimal("10")},
            row_counts={"A": 1, "B": 1},
            valid_rows=2,
        )
        by_total = json.loads(summary.render_json(result, sort="total"))["categories"]
        self.assertEqual([entry["category"] for entry in by_total], ["B", "A"])
        by_category = json.loads(summary.render_json(result, sort="category"))["categories"]
        self.assertEqual([entry["category"] for entry in by_category], ["A", "B"])
        reversed_total = json.loads(summary.render_json(result, sort="total", reverse=True))["categories"]
        self.assertEqual([entry["category"] for entry in reversed_total], ["A", "B"])

    def test_summarize_rows_tracks_row_counts(self) -> None:
        rows = [
            {"category": "食品", "amount": "10"},
            {"category": "食品", "amount": "5"},
            {"category": "交通", "amount": "2"},
        ]
        result = summary.summarize_rows(rows)
        self.assertEqual(result.row_counts, {"食品": 2, "交通": 1})

    def test_cli_json_output_is_valid_json(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n交通,2\n食品,5\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["grand_total"], "17")
        self.assertEqual(payload["valid_rows"], 3)
        self.assertEqual(payload["skipped_rows"], 0)
        self.assertEqual(
            payload["categories"],
            [
                {"category": "食品", "total": "15", "rows": 2},
                {"category": "交通", "total": "2", "rows": 1},
            ],
        )

    def test_cli_json_keeps_warning_on_stderr(self) -> None:
        source = self.dir / "dirty.csv"
        source.write_text("category,amount\n食品,10\n坏行,x\n", encoding="utf-8")
        result = self.run_cli("dirty.csv", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["skipped_rows"], 1)
        self.assertEqual(payload["skipped"][0]["line"], 3)
        self.assertIn("警告", result.stderr)

    def test_cli_json_written_to_output_file(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "--json", "-o", "out/summary.json")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads((self.dir / "out" / "summary.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["categories"][0]["category"], "食品")
        self.assertEqual(payload["categories"][0]["total"], "10")

    def test_cli_json_takes_precedence_over_format_table(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n", encoding="utf-8")
        result = self.run_cli("sales.csv", "--json", "--format", "table")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["grand_total"], "10")

    def test_cli_default_output_stays_csv(self) -> None:
        source = self.dir / "sales.csv"
        source.write_text("category,amount\n食品,10\n", encoding="utf-8")
        result = self.run_cli("sales.csv")
        self.assertEqual(result.returncode, 0, result.stderr)
        rows = list(csv.reader(io.StringIO(result.stdout)))
        self.assertEqual(rows, [["category", "total"], ["食品", "10"]])


if __name__ == "__main__":
    unittest.main(verbosity=2)
