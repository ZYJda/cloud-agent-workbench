# CSV 分类金额汇总工具

`summary.py` 是一个**零第三方依赖**的命令行工具：读取 CSV 文件，按 `category` 列分组，
对每组的 `amount` 列求和，并输出汇总结果。金额使用 `decimal.Decimal` 精确计算，不存在浮点误差。

## 文件清单

| 文件 | 说明 |
| --- | --- |
| `summary.py` | 工具本体（纯标准库，可直接复制使用） |
| `test_summary.py` | unittest 测试用例，共 34 个测试 |
| `example/sales.csv` | 演示用的示例数据（含千分位、货币符号、负数、脏数据等情况） |
| `README.md` | 本使用说明 |

## 环境要求

- Python 3.8 或更高版本（实测环境为 Python 3.11 / Windows）
- **无需安装任何第三方包**，只使用 `csv`、`decimal`、`argparse`、`dataclasses` 等标准库

## 快速开始

在 `artifacts/` 目录下执行：

```bash
python summary.py example/sales.csv
```

输出（按金额从大到小排序）：

```csv
category,total
餐饮,1234.56
住宿,420.00
食品,214.40
(空),60.00
交通,16.50
```

同时标准错误会提示被跳过的脏数据行：

```text
警告: 已跳过 1 行无效金额（第 8 行）
```

常用变体：

```bash
# 指定分类列 / 金额列，并写入结果文件
python summary.py example/sales.csv -c 类别 -a 金额 -o 汇总.csv

# 以对齐表格输出，并按分类名排序
python summary.py example/sales.csv --format table --sort category

# 以 JSON 输出（供程序消费）
python summary.py example/sales.csv --json

# 从标准输入读取（管道用法）
type example/sales.csv | python summary.py -

# 不写表头、安静模式（不输出警告）
python summary.py example/sales.csv --no-header --quiet
```

## 命令行参数

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `input`（位置参数） | 必填 | 输入 CSV 路径；使用 `-` 表示从标准输入读取 |
| `-c, --category-column` | `category` | 分类列名 |
| `-a, --amount-column` | `amount` | 金额列名 |
| `-d, --delimiter` | 自动识别 | CSV 分隔符，可选 `,` `;` `\t` `|` |
| `--encoding` | `utf-8-sig` | 输入文件编码，默认兼容带 BOM 的 UTF-8 |
| `-o, --output` | 标准输出 | 输出文件路径，父目录会自动创建 |
| `--format` | `csv` | 输出格式：`csv` 或 `table` |
| `--json` | 关闭 | 以 JSON 格式输出（优先于 `--format`） |
| `--sort` | `total` | 排序依据：`total`（金额降序）或 `category`（分类名正序） |
| `--reverse` | 关闭 | 反向排序（金额从小到大 / 分类名 Z→A） |
| `--no-header` | 关闭 | 输出中不包含表头 |
| `--strict` | 关闭 | 遇到无效金额立即报错退出，而不是跳过该行 |
| `-q, --quiet` | 关闭 | 不在标准错误输出警告信息 |

退出码：`0` 成功；`2` 参数或数据错误（找不到列、文件不存在、严格模式下的无效金额等）。

## JSON 输出

加上 `--json` 后，标准输出变为 JSON（警告信息仍写入标准错误），便于脚本或下游系统消费。
原有的 `csv` 与 `table` 输出完全保留，不加 `--json` 时行为与之前一致。

```bash
python summary.py example/sales.csv --json
```

```json
{
  "grand_total": "1945.46",
  "valid_rows": 7,
  "skipped_rows": 1,
  "categories": [
    {
      "category": "餐饮",
      "total": "1234.56",
      "rows": 1
    },
    {
      "category": "住宿",
      "total": "420.00",
      "rows": 1
    },
    {
      "category": "食品",
      "total": "214.40",
      "rows": 2
    },
    {
      "category": "(空)",
      "total": "60.00",
      "rows": 1
    },
    {
      "category": "交通",
      "total": "16.50",
      "rows": 2
    }
  ],
  "skipped": [
    {
      "line": 8,
      "reason": "无法解析的金额: '待确认'"
    }
  ]
}
```

字段说明：

| 字段 | 含义 |
| --- | --- |
| `grand_total` | 全部分类的金额总计 |
| `valid_rows` | 参与汇总的数据行数 |
| `skipped_rows` | 因金额无效被跳过的行数 |
| `categories` | 各分类的合计（`category` 分类名、`total` 金额、`rows` 该分类的行数） |
| `skipped` | 被跳过的行明细（`line` 行号、`reason` 原因） |

- `categories` 的排序与 `--sort` / `--reverse` 一致，默认按金额降序。
- 金额一律以**字符串**输出，避免 JSON 数字的双精度舍入丢失精度；
  需要数值参与计算时，请用 `decimal.Decimal` 自行转换。
- 中文以原样输出（`ensure_ascii=False`），无需额外转义。

## 汇总规则

1. **分组键**：`category` 列的值去除首尾空白后作为分组键；空白分类统一归入 `(空)`。
2. **列名匹配**：忽略大小写、空格、下划线和连字符，且支持唯一子串匹配
   （例如 `category` 能匹配表头 `Category Name`）。
3. **金额解析**：下列写法都能正确识别

| 写法 | 解析结果 |
| --- | --- |
| `1234.56` | `1234.56` |
| `¥1,234.56`、`$2,000` | `1234.56`、`2000` |
| `1 234.56`（含空格或全角空格） | `1234.56` |
| `-12.50` | `-12.50` |
| `(12.50)`（会计负数） | `-12.50` |
| `12.50-`（尾随负号） | `-12.50` |
| `+8` | `8` |

4. **无效金额**：空值、非数字等无法解析的内容，默认跳过该行并在标准错误中提示行号；
   使用 `--strict` 则立即以退出码 `2` 终止。
5. **其他列**：除 `category` 与 `amount` 外的列一律忽略。
6. **空行**：自动跳过。

## 作为 Python 模块调用

```python
from decimal import Decimal
from summary import summarize_file, render_csv

result = summarize_file("example/sales.csv")           # -> SummaryResult
print(result.totals["食品"])                            # -> Decimal('214.40')
print(result.grand_total)                               # -> Decimal('1945.46')
print(result.valid_rows, result.skipped_count)          # -> 7 1
print(render_csv(result))                               # 汇总结果 CSV 文本
```

常用 API：

- `summarize_file(path, category_column="category", amount_column="amount", delimiter=None, encoding="utf-8-sig", strict=False)`
- `summarize_stream(stream, ...)`：从已打开的文本流汇总（管道输入）
- `summarize_rows(rows, ...)`：直接对 `dict` 序列汇总
- `parse_amount(raw)`：把单个单元格解析为 `Decimal`，失败抛 `ValueError`
- `render_csv(result, ...)` / `render_table(result, ...)`：渲染输出
- `render_json(result, ...)`：渲染 JSON 文本

## 运行测试

测试使用标准库 `unittest`，无需安装 pytest：

```bash
python test_summary.py -v
```

或用 discover 方式：

```bash
python -m unittest discover -s artifacts -v
```

测试覆盖：金额解析的各类写法、分类求和、脏数据跳过与 `--strict` 报错、空分类处理、
列名大小写/空格匹配、分号分隔符自动识别、UTF-8 BOM 文件、缺失文件与缺失列的报错，
JSON 输出的字段结构、金额精度、排序与被跳过行明细，
以及命令行的标准输出、输出文件、标准输入、表格格式与退出码等端到端行为。

## 注意事项

- 千分位按**逗号**处理（`1,234.56` 视为 1234.56）。欧洲写法 `1.234,56` 不支持。
- 输出金额不做四舍五入，直接沿用 `Decimal` 的精度；同一分类下小数位不同会按最大位数保留。
- 大文件按行流式处理，内存占用与数据行数无关（仅表头与分组字典占用内存）。
